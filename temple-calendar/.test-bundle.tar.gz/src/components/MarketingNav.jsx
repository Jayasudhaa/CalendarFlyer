/**
 * MarketingNav - shared top nav for the public marketing site
 * (Landing, Features, Pricing, About, Contact, Careers, Privacy, Terms, Security).
 * Extracted from PremiumLanding.jsx so every page gets the same header
 * and the same working links instead of duplicating this markup everywhere.
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PremiumButton from '../PremiumButton';

export default function MarketingNav() {
  const navigate = useNavigate();
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className="fixed top-0 w-full z-50 transition-all duration-300"
      style={{
        background: scrollY > 50 ? 'rgba(10, 14, 39, 0.9)' : 'rgba(10, 14, 39, 0.55)',
        backdropFilter: 'blur(20px)',
      }}
    >
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <button onClick={() => navigate('/')} className="flex items-center gap-3">
          <img src="/calendarfly-icon.png" alt="CalendarFly" className="w-10 h-10 rounded-xl" />
          <span className="flex flex-col items-start leading-none">
            <span
              className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent"
              style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
            >
              CalendarFly
            </span>
            <span className="hidden sm:block text-[10px] tracking-wide text-gray-400 mt-0.5">
              Events <span className="text-orange-400">Simplified</span>, Community <span className="text-pink-400">Amplified</span>
            </span>
          </span>
        </button>

        <div className="hidden md:flex items-center gap-8">
          <button onClick={() => navigate('/features')} className="hover:text-purple-400 transition-colors">Features</button>
          <button onClick={() => navigate('/pricing')} className="hover:text-purple-400 transition-colors">Pricing</button>
          <button onClick={() => navigate('/about')} className="hover:text-purple-400 transition-colors">About</button>
          <button onClick={() => navigate('/contact')} className="hover:text-purple-400 transition-colors">Contact</button>
          <button onClick={() => navigate('/login')} className="hover:text-purple-400 transition-colors">
            Login
          </button>
          <PremiumButton onClick={() => navigate('/signup')} size="sm">
            Start Free Trial
          </PremiumButton>
        </div>
      </div>
    </nav>
  );
}
