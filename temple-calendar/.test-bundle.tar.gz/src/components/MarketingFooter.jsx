/**
 * MarketingFooter - shared footer for the public marketing site.
 * Extracted from PremiumLanding.jsx and wired up so Product / Company / Legal
 * links actually go somewhere instead of the old placeholder href="#".
 */
import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function MarketingFooter() {
  const navigate = useNavigate();
  const year = new Date().getFullYear();

  const go = (path) => (e) => { e.preventDefault(); navigate(path); };

  return (
    <footer className="border-t border-white/10 py-12 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <button onClick={() => navigate('/')} className="flex items-center gap-3 mb-4">
              <img src="/calendarfly-icon.png" alt="CalendarFly" className="w-10 h-10 rounded-xl" />
              <span className="text-xl font-bold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>CalendarFly</span>
            </button>
            <p className="text-gray-400">
              Event management for small orgs, nonprofits & cultural centers
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-4">Product</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="/features" onClick={go('/features')} className="hover:text-white transition-colors">Features</a></li>
              <li><a href="/pricing" onClick={go('/pricing')} className="hover:text-white transition-colors">Pricing</a></li>
              <li><a href="/signup" onClick={go('/signup')} className="hover:text-white transition-colors">Sign Up</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Company</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="/about" onClick={go('/about')} className="hover:text-white transition-colors">About</a></li>
              <li><a href="/contact" onClick={go('/contact')} className="hover:text-white transition-colors">Contact</a></li>
              <li><a href="/careers" onClick={go('/careers')} className="hover:text-white transition-colors">Careers</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Legal</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="/privacy" onClick={go('/privacy')} className="hover:text-white transition-colors">Privacy</a></li>
              <li><a href="/terms" onClick={go('/terms')} className="hover:text-white transition-colors">Terms</a></li>
              <li><a href="/security" onClick={go('/security')} className="hover:text-white transition-colors">Security</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/10 pt-8 text-center text-gray-400">
          <p>© {year} CalendarFly. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
