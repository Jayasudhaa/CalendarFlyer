import React, { useState } from 'react';
import { FONTS, STYLES, COLORS, LANGUAGES } from '../constants';

const { sectionLabel: sL, input: inp } = STYLES;

export default function TextPanel({ fabricRef, activeLang, translating, onTranslate }) {
  const getActive = () => fabricRef.current?.getActiveObject();

  const bold       = () => { const o = getActive(); if (o) { o.set('fontWeight',  o.fontWeight  === 'bold'   ? 'normal' : 'bold');   fabricRef.current.renderAll(); } };
  const italic     = () => { const o = getActive(); if (o) { o.set('fontStyle',   o.fontStyle   === 'italic' ? 'normal' : 'italic'); fabricRef.current.renderAll(); } };
  const underline  = () => { const o = getActive(); if (o) { o.set('underline',   !o.underline);                                      fabricRef.current.renderAll(); } };
  const setSize    = (v) => { const o = getActive(); if (o) { o.set('fontSize',   +v);           fabricRef.current.renderAll(); } };
  const setColor   = (v) => { const o = getActive(); if (o) { o.set('fill',       v);            fabricRef.current.renderAll(); } };
  const setFont    = (v) => { const o = getActive(); if (o) { o.set('fontFamily', v);            fabricRef.current.renderAll(); } };

  function addText() {
    const c = fabricRef.current; if (!c) return;
    // Named custom_text_<timestamp> so the translate buttons in the top
    // toolbar (which only touch a known set of named text objects) can
    // find and translate any text box added here too.
    c.add(new window.fabric.Textbox('New Text', {
      left: c.width / 2, top: c.height / 2, originX: 'center',
      fontFamily: 'Playfair Display', fontSize: 30, fill: '#7c2d12',
      width: c.width * 0.7, textAlign: 'center',
      name: `custom_text_${Date.now()}`, selectable: true, evented: true,
    }));
    c.renderAll();
  };

  function deleteSelected() {
    const c = fabricRef.current;
    const o = c?.getActiveObject();
    if (o) { c.remove(o); c.renderAll(); }
  };

  return (
    <div>
      <div style={{ color: COLORS.text, fontWeight: '700', fontSize: '0.95rem', marginBottom: 4 }}>🔤 Text</div>
      <div style={{ color: COLORS.textMuted, fontSize: '0.75rem', marginBottom: 14 }}>Click any text on canvas to select</div>

      {/* Language — merged in from the old Languages panel so translating
          and editing text live in one place. */}
      {onTranslate && (
        <div style={{ marginBottom: 16 }}>
          <span style={sL}>Language</span>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginBottom: 4 }}>
            {LANGUAGES.map(lang => {
              const active = activeLang === lang.code;
              return (
                <button key={lang.code} onClick={() => onTranslate(lang.code)} disabled={translating} style={{
                  display: 'flex', alignItems: 'center', gap: 5,
                  padding: '6px 10px', borderRadius: 20, cursor: translating ? 'wait' : 'pointer',
                  border: `1.5px solid ${active ? COLORS.accent : COLORS.border}`,
                  background: active ? COLORS.accentSoft : '#fff',
                  color: active ? COLORS.accent : COLORS.text,
                  fontSize: '0.75rem', fontWeight: active ? '700' : '500',
                }}>
                  <span>{lang.flag}</span>{lang.label}
                  {active && <span style={{ fontSize: '0.65rem' }}>✓</span>}
                </button>
              );
            })}
          </div>
          {translating && <div style={{ color: COLORS.textMuted, fontSize: '0.72rem' }}>Translating…</div>}
          <div style={{ color: COLORS.textFaint, fontSize: '0.66rem', marginTop: 4, lineHeight: 1.5 }}>
            Translates the title, date, time, description, sponsorship line, and any text boxes below — temple name/address always stay in English.
          </div>
        </div>
      )}

      {/* Style buttons */}
      <div style={{ display: 'flex', gap: 5, marginBottom: 14 }}>
        {[
          { l: 'B', style: { fontWeight: 'bold' },            fn: bold      },
          { l: 'I', style: { fontStyle: 'italic' },           fn: italic    },
          { l: 'U', style: { textDecoration: 'underline' },   fn: underline },
        ].map(({ l, style, fn }) => (
          <button key={l} onClick={fn} style={{
            width: 38, height: 38, background: '#f9fafb',
            border: `1.5px solid ${COLORS.border}`, color: COLORS.text,
            borderRadius: 7, cursor: 'pointer', fontSize: '0.95rem', ...style,
          }}>{l}</button>
        ))}
      </div>

      <span style={sL}>Font Size</span>
      <input type="range" min="10" max="130" defaultValue="28"
        style={{ width: '100%', accentColor: COLORS.accent, marginBottom: 14 }}
        onChange={e => setSize(e.target.value)} />

      <span style={sL}>Text Color</span>
      <input type="color" defaultValue="#7c2d12"
        style={{ width: '100%', height: 38, border: 'none', cursor: 'pointer', borderRadius: 6, marginBottom: 14 }}
        onChange={e => setColor(e.target.value)} />

      <span style={sL}>Font Family</span>
      <select style={{ ...inp, marginBottom: 14 }} onChange={e => setFont(e.target.value)}>
        {FONTS.map(f => <option key={f} value={f}>{f}</option>)}
      </select>

      <button onClick={addText} style={{
        width: '100%', padding: '10px', background: COLORS.accent,
        border: 'none', color: 'white', borderRadius: 8,
        cursor: 'pointer', fontWeight: 'bold', marginBottom: 6, fontSize: '0.85rem',
      }}>
        + Add Text
      </button>
      <div style={{ color: COLORS.textMuted, fontSize: '0.68rem', marginBottom: 8, lineHeight: 1.5 }}>
        Added text boxes are also translated when you switch language above.
      </div>

      <button onClick={deleteSelected} style={{
        width: '100%', padding: '10px', background: 'transparent',
        border: `1px solid ${COLORS.danger}`, color: COLORS.danger,
        borderRadius: 8, cursor: 'pointer', fontSize: '0.85rem', marginBottom: 8,
      }}>
        🗑 Delete Selected
      </button>
    </div>
  );
}
