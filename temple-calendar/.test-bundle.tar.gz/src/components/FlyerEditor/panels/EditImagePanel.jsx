import React from 'react';
import { STYLES, COLORS } from '../constants';

const { sectionLabel: sL, input: inp } = STYLES;

const CROP_PRESETS = [
  { label: '1:1',  val: '1:1'  },
  { label: '4:3',  val: '4:3'  },
  { label: '3:4',  val: '3:4'  },
  { label: '16:9', val: '16:9' },
  { label: 'Free', val: null   },
];

// Split out of AIVisualPanel — image generation and image editing are two
// different jobs (one creates a photo, the other adjusts one already on the
// canvas), and having both in a single panel made AI Visual feel cluttered.
// Selecting any image object on the canvas now jumps straight here (see
// handleSelectionChange in index.jsx), the same way clicking the empty
// photo placeholder jumps to AI Visual.
export default function EditImagePanel({
  selectedObject,
  applyFilter, applyBlur, handleCrop, handleRemoveBgApi, removingBg,
  posterTitleText, posterMessageText, onPosterOverlayChange,
}) {
  const isImageSelected = selectedObject?.type === 'image';
  const isFullFrameImageSelected = selectedObject?.name === 'full_frame_img';

  return (
    <div>
      <div style={{ color: COLORS.text, fontWeight: '700', fontSize: '0.95rem', marginBottom: 4 }}>🎚 Edit Image</div>
      <div style={{ color: COLORS.textMuted, fontSize: '0.75rem', marginBottom: 14 }}>Click any photo on the canvas to select it</div>

      {!isImageSelected && (
        <div style={{
          color: COLORS.textFaint, fontSize: '0.78rem', fontStyle: 'italic',
          padding: '24px 12px', textAlign: 'center', border: `1.5px dashed ${COLORS.border}`, borderRadius: 10,
        }}>
          🖼 No photo selected — click one on the canvas to crop, remove its background, or adjust brightness/contrast.
        </div>
      )}

      {isImageSelected && (
        <>
          {isFullFrameImageSelected ? (
            <div style={{ marginBottom: 14 }}>
              <div style={{ color: COLORS.text, fontSize: '0.75rem', fontWeight: '600', marginBottom: 6 }}>📝 Title &amp; Message</div>
              <input value={posterTitleText || ''} onChange={e => onPosterOverlayChange({ title: e.target.value })}
                placeholder="Title text over the photo" style={{ ...inp, marginBottom: 6, fontSize: '0.78rem' }} />
              <textarea value={posterMessageText || ''} onChange={e => onPosterOverlayChange({ message: e.target.value })}
                placeholder="Message text over the photo" rows={3}
                style={{ ...inp, resize: 'vertical', fontSize: '0.75rem', marginBottom: 0 }} />
              <div style={{ color: COLORS.textFaint, fontSize: '0.68rem', marginTop: 4, lineHeight: 1.5 }}>
                Adds movable, editable text on top of the photo. Leave blank to remove.
              </div>
            </div>
          ) : (
            <div style={{ marginBottom: 14 }}>
              <span style={sL}>✂ Crop</span>
              <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                {CROP_PRESETS.map(({ label, val }) => (
                  <button key={label}
                    onClick={() => val ? handleCrop(val) : null}
                    style={{
                      padding: '5px 11px', border: `1px solid ${COLORS.border}`,
                      background: '#f9fafb', color: COLORS.text,
                      borderRadius: 6, cursor: 'pointer', fontSize: '0.72rem',
                    }}>{label}</button>
                ))}
              </div>
            </div>
          )}

          <div style={{ marginBottom: 14 }}>
            <span style={sL}>🪄 Remove Background</span>
            <button onClick={handleRemoveBgApi} disabled={removingBg} style={{
              width: '100%', padding: '10px',
              background: removingBg ? '#f3f4f6' : 'linear-gradient(135deg,#6366f1,#4338ca)',
              color: removingBg ? COLORS.textMuted : 'white', border: 'none',
              borderRadius: 8, cursor: removingBg ? 'not-allowed' : 'pointer',
              fontWeight: '600', fontSize: '0.8rem',
            }}>
              {removingBg
                ? <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                    <span style={{ animation: 'spin 1s linear infinite', display: 'inline-block' }}>⏳</span>
                    Removing…
                  </span>
                : '🪄 Remove Background'}
            </button>
            <div style={{ color: COLORS.textFaint, fontSize: '0.65rem', marginTop: 4 }}>
              Requires REMOVE_BG_API_KEY in server .env
            </div>
          </div>

          <span style={sL}>💧 Blur</span>
          <input type="range" min="0" max="100" defaultValue="0"
            style={{ width: '100%', accentColor: COLORS.accent, marginBottom: 14 }}
            onChange={e => applyBlur(+e.target.value)} />
        </>
      )}

      {['Brightness', 'Contrast'].map(type => (
        <label key={type} style={{ display: 'block', color: COLORS.textMuted, marginBottom: 12 }}>
          <div style={{ fontSize: '0.75rem', marginBottom: 4 }}>{type === 'Brightness' ? '☀' : '◑'} {type}</div>
          <input type="range" min="-100" max="100" defaultValue="0"
            style={{ width: '100%', accentColor: COLORS.accent }}
            onChange={e => applyFilter(type, +e.target.value)} />
        </label>
      ))}
    </div>
  );
}
