import React from 'react';
import { COLORS } from '../constants';

function UploadButton({ label, sub, icon, onChange, accent }) {
  const border = accent ? `2px dashed ${COLORS.accent}` : `2px dashed ${COLORS.border}`;
  const bg     = accent ? COLORS.accentSoft : '#fafafa';
  const color  = accent ? COLORS.accent : COLORS.textMuted;

  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ color: COLORS.text, fontSize: '0.82rem', fontWeight: '600', marginBottom: 2 }}>{icon} {label}</div>
      <div style={{ color: COLORS.textFaint, fontSize: '0.7rem', marginBottom: 6 }}>{sub}</div>
      <div style={{ position: 'relative', width: '100%' }}>
        <button style={{ width: '100%', padding: '14px', border, background: bg, color, borderRadius: 10, cursor: 'pointer', fontSize: '0.82rem', fontWeight: accent ? '600' : '400', pointerEvents: 'none' }}>
          📤 {label}
        </button>
        <input type="file" accept="image/*" onChange={onChange}
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0, cursor: 'pointer' }} />
      </div>
    </div>
  );
}

// "Uploads" panel — your own photos/backgrounds. Logo upload lives in the
// Brand panel now, since it's an org-identity setting rather than
// per-flyer content.
export default function UploadPanel({ onUpload, onSetBackground, hasBg, onRemoveBg }) {
  return (
    <div>
      <div style={{ color: COLORS.text, fontWeight: '700', fontSize: '0.95rem', marginBottom: 14 }}>☁️ Uploads</div>

      <UploadButton label="Deity / Event Photo" sub="Placed in center image area"          icon="🖼" onChange={e => onUpload(e, false)} />
      <UploadButton label="Background Template" sub="Fills entire canvas behind all elements" icon="🎨" accent onChange={e => onSetBackground(e)} />

      <div style={{ marginBottom: 14 }}>
        <div style={{ color: COLORS.text, fontSize: '0.82rem', fontWeight: '600', marginBottom: 2 }}>🔁 Selected Image as Background</div>
        <div style={{ color: COLORS.textFaint, fontSize: '0.7rem', marginBottom: 6 }}>Select any image on canvas, then click</div>
        <button onClick={() => onSetBackground(null)} style={{ width: '100%', padding: '11px', border: `1.5px solid ${COLORS.border}`, background: '#f9fafb', color: COLORS.text, borderRadius: 9, cursor: 'pointer', fontSize: '0.8rem', fontWeight: '600' }}>
          ⬇ Set Selected as Background
        </button>
      </div>

      {hasBg && (
        <div style={{ marginBottom: 14, padding: '12px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 9 }}>
          <div style={{ color: '#b91c1c', fontSize: '0.8rem', fontWeight: '600', marginBottom: 6 }}>🖼 Background is active</div>
          <button onClick={onRemoveBg} style={{ width: '100%', padding: '10px', background: '#fee2e2', border: `1px solid ${COLORS.danger}`, color: '#b91c1c', borderRadius: 8, cursor: 'pointer', fontSize: '0.8rem', fontWeight: '600' }}>
            🗑 Remove Background
          </button>
        </div>
      )}

      <div style={{ marginTop: 4, padding: '12px', background: '#eef2ff', border: '1px solid #c7d2fe', borderRadius: 9, fontSize: '0.72rem', color: '#4338ca', lineHeight: 1.9 }}>
        💡 <strong>Tips</strong><br />
        • Background sits behind all text &amp; images<br />
        • Use AI Visual → Edit tools to crop &amp; blur<br />
        • Double-click text to edit inline<br />
        • Delete / Backspace removes selected object
      </div>
    </div>
  );
}
