import React from 'react';
import { STYLES, COLORS } from '../constants';

const { sectionLabel: sL } = STYLES;

// Org identity — logo placement. Its own tab, shown regardless of DIY-vs-AI
// mode: a hand-built flyer needs your logo just as much as an AI-generated
// one does. Reference photos stay inside AI Visual instead (they only mean
// something when AI is grounding a generation in them), but Brand itself is
// mode-independent. Brand accent color was removed — theme colors alone now
// drive header/title/date/sponsorship text.
export default function BrandPanel({
  onUploadLogo, logoPreviewUrl, onRemoveLogo,
}) {
  return (
    <div>
      <div style={{ color: COLORS.text, fontWeight: '700', fontSize: '0.95rem', marginBottom: 2 }}>🎨 Brand</div>
      <div style={{ color: COLORS.textMuted, fontSize: '0.75rem', marginBottom: 14 }}>Your organization's logo</div>

      <span style={sL}>Logo</span>
      <div style={{ color: COLORS.textFaint, fontSize: '0.7rem', marginBottom: 6 }}>Placed in the header corners of your flyer</div>

      {logoPreviewUrl ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14, padding: '9px 11px', border: `1.5px solid ${COLORS.border}`, borderRadius: 10, background: '#fff' }}>
          <img src={logoPreviewUrl} alt="Uploaded logo" style={{ width: 48, height: 48, objectFit: 'contain', borderRadius: 6, border: `1px solid ${COLORS.border}`, background: '#f9fafb' }} />
          <div style={{ flex: 1, fontSize: '0.76rem', color: COLORS.text, fontWeight: '600' }}>Logo uploaded</div>
          <label style={{ fontSize: '0.7rem', color: COLORS.accent, cursor: 'pointer', fontWeight: '600' }}>
            Replace
            <input type="file" accept="image/*" onChange={e => onUploadLogo?.(e)} style={{ display: 'none' }} />
          </label>
          <button onClick={() => onRemoveLogo?.()} style={{ background: 'none', border: 'none', color: COLORS.danger, fontSize: '0.7rem', cursor: 'pointer', padding: 0, fontWeight: '600' }}>
            ✕ Remove
          </button>
        </div>
      ) : (
        <div style={{ position: 'relative', width: '100%', marginBottom: 14 }}>
          <button style={{
            width: '100%', padding: '14px', border: `2px dashed ${COLORS.border}`,
            background: '#fafafa', color: COLORS.textMuted, borderRadius: 10,
            cursor: 'pointer', fontSize: '0.82rem', pointerEvents: 'none',
          }}>
            📤 Upload logo
          </button>
          <input type="file" accept="image/*" onChange={e => onUploadLogo?.(e)}
            style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0, cursor: 'pointer' }} />
        </div>
      )}
    </div>
  );
}
