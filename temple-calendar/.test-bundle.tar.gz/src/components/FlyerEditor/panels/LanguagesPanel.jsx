import React from 'react';
import { LANGUAGES, COLORS } from '../constants';

export default function LanguagesPanel({ activeLang, translating, onTranslate }) {
  return (
    <div>
      <div style={{ color: COLORS.text, fontWeight: '700', fontSize: '0.95rem', marginBottom: 2 }}>🌐 Languages</div>
      <div style={{ color: COLORS.textMuted, fontSize: '0.75rem', marginBottom: 14 }}>Translate all editable flyer text</div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {LANGUAGES.map(lang => {
          const active = activeLang === lang.code;
          return (
            <button key={lang.code} onClick={() => onTranslate(lang.code)} disabled={translating} style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '9px 12px', borderRadius: 8, cursor: translating ? 'wait' : 'pointer',
              border: `1.5px solid ${active ? COLORS.accent : COLORS.border}`,
              background: active ? COLORS.accentSoft : '#fff',
              color: active ? COLORS.accent : COLORS.text,
              fontSize: '0.82rem', fontWeight: active ? '700' : '500',
            }}>
              <span>{lang.flag}</span>{lang.label}
              {active && <span style={{ marginLeft: 'auto', fontSize: '0.68rem' }}>✓ Active</span>}
            </button>
          );
        })}
      </div>

      {translating && (
        <div style={{ marginTop: 12, color: COLORS.textMuted, fontSize: '0.75rem' }}>Translating…</div>
      )}

      <div style={{ marginTop: 14, padding: '10px 12px', background: COLORS.accentSoft, border: `1px solid ${COLORS.accent}33`, borderRadius: 8, fontSize: '0.7rem', color: COLORS.accent, lineHeight: 1.6 }}>
        💡 Translates the title, date, time, description, sponsorship line, and any text boxes you've added — temple name/address always stay in English.
      </div>
    </div>
  );
}
