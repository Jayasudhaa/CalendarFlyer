import React from 'react';
import { STYLES, COLORS } from '../constants';

const { sectionLabel: sL, input: inp } = STYLES;

const STOCK_CATEGORIES = [
  { label: '🌸 Garland',  q: 'flower garland temple indian' },
  { label: '🪔 Deepam',   q: 'oil lamp deepam diya temple' },
  { label: '🎨 Rangoli',  q: 'rangoli colorful indian festival' },
  { label: '🌺 Marigold', q: 'marigold flowers decoration indian' },
  { label: '🐘 Elephant', q: 'decorated elephant temple india' },
  { label: '🪷 Lotus',    q: 'lotus flower water pink' },
  { label: '🎊 Festival', q: 'indian festival celebration colorful' },
  { label: '🕌 Temple',   q: 'hindu temple gopuram india' },
  { label: '🌙 Diwali',   q: 'diwali lights candles festival' },
  { label: '🌾 Harvest',  q: 'pongal harvest festival india' },
  { label: '🎭 Navratri', q: 'navratri garba festival dance' },
  { label: '🌿 Thoran',   q: 'mango leaves torana temple decoration' },
];
// Must match the folder names server/routes/imageLibrary.js's CATEGORY_MAP
// actually returns ('Deities' | 'Festivals' | 'Flowers' | 'Rangoli' | 'General').
const LIBRARY_CATS = ['All', 'Deities', 'Festivals', 'Flowers', 'Rangoli', 'General'];

const tileWrap = {
  cursor: 'grab', borderRadius: 8, overflow: 'hidden',
  border: `2px solid ${COLORS.border}`, aspectRatio: '1', background: '#f3f4f6',
  transition: 'border-color 0.15s, transform 0.1s',
};

export default function PhotosPanel({
  imageTab, setImageTab,
  libraryLoading, libraryError, filteredLibrary, libraryCat, setLibraryCat,
  stockResults, stockLoading, stockError, stockQuery, stockSearchInput, setStockSearchInput, handleStockSearch,
  onPlaceImage, onDragStart, onDragEnd,
}) {
  return (
    <div>
      <div style={{ color: COLORS.text, fontWeight: '700', fontSize: '0.95rem', marginBottom: 10 }}>🖼 Photos</div>

      <div style={{ display: 'flex', background: '#f3f4f6', borderRadius: 8, padding: 3, marginBottom: 14, gap: 2 }}>
        {[{ id: 'library', label: '📚 Library' }, { id: 'stock', label: '🔍 Stock' }].map(tab => (
          <button key={tab.id} onClick={() => setImageTab(tab.id)} style={{
            flex: 1, padding: '6px 2px', border: 'none', borderRadius: 6, cursor: 'pointer',
            background: imageTab === tab.id ? COLORS.accent : 'transparent',
            color: imageTab === tab.id ? 'white' : COLORS.textMuted,
            fontSize: '0.75rem', fontWeight: imageTab === tab.id ? '700' : '500',
          }}>{tab.label}</button>
        ))}
      </div>

      {imageTab === 'library' && (
        <div>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 10 }}>
            {LIBRARY_CATS.map(cat => (
              <button key={cat} onClick={() => setLibraryCat(cat)} style={{
                padding: '5px 10px', borderRadius: 20, cursor: 'pointer',
                border: `1px solid ${libraryCat === cat ? COLORS.accent : COLORS.border}`,
                background: libraryCat === cat ? COLORS.accent : '#fff',
                color: libraryCat === cat ? 'white' : COLORS.textMuted,
                fontSize: '0.72rem', fontWeight: libraryCat === cat ? '700' : '400',
              }}>{cat}</button>
            ))}
          </div>

          {libraryLoading && <div style={{ textAlign: 'center', color: COLORS.textMuted, fontSize: '0.82rem', padding: '20px 0' }}>Loading library…</div>}
          {libraryError  && <div style={{ color: '#b91c1c', fontSize: '0.78rem', background: '#fef2f2', padding: '10px', borderRadius: 6, marginBottom: 8, lineHeight: 1.6 }}>⚠ {libraryError}</div>}

          {!libraryLoading && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 5 }}>
              {filteredLibrary.map((img, i) => (
                <div key={i}
                  onClick={() => onPlaceImage(img.url)}
                  draggable="true"
                  onDragStart={e => {
                    e.dataTransfer.setData('imageUrl', img.url);
                    e.dataTransfer.setData('text/plain', img.url);
                    e.dataTransfer.effectAllowed = 'copy';
                    onDragStart?.(img.url);
                  }}
                  onDragEnd={() => onDragEnd?.()}
                  style={tileWrap}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = COLORS.accent; e.currentTarget.style.transform = 'scale(1.04)'; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = COLORS.border; e.currentTarget.style.transform = 'scale(1)'; }}
                >
                  <img src={img.thumb || img.url} alt={img.name}
                    style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', pointerEvents: 'none' }} />
                </div>
              ))}
              {filteredLibrary.length === 0 && !libraryLoading && (
                <div style={{ gridColumn: '1/-1', textAlign: 'center', color: COLORS.textMuted, fontSize: '0.82rem', padding: '20px 0', lineHeight: 2 }}>
                  No images yet.<br />
                  <span style={{ fontSize: '0.72rem', color: COLORS.textFaint }}>
                    Upload to S3:<br />temple-images/library/{libraryCat === 'All' ? 'Deities' : libraryCat}/
                  </span>
                </div>
              )}
            </div>
          )}

          <div style={{ marginTop: 12, padding: '10px 12px', background: COLORS.accentSoft, border: `1px solid ${COLORS.accent}33`, borderRadius: 7, fontSize: '0.72rem', color: COLORS.accent, lineHeight: 1.8 }}>
            💡 Click to place · Drag onto canvas
          </div>
        </div>
      )}

      {imageTab === 'stock' && (
        <div>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 10 }}>
            {STOCK_CATEGORIES.map(({ label, q }) => (
              <button key={q} onClick={() => handleStockSearch(q)} style={{
                padding: '4px 9px', borderRadius: 20, cursor: 'pointer',
                border: `1px solid ${stockQuery === q ? COLORS.accent : COLORS.border}`,
                background: stockQuery === q ? COLORS.accent : '#fff',
                color: stockQuery === q ? 'white' : COLORS.text,
                fontSize: '0.72rem', fontWeight: '500',
              }}>{label}</button>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 5, marginBottom: 10 }}>
            <input value={stockSearchInput} onChange={e => setStockSearchInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleStockSearch(stockSearchInput)}
              placeholder="e.g. rangoli, deepam, lotus..."
              style={{ ...inp, flex: 1, marginBottom: 0, fontSize: '0.75rem' }} />
            <button onClick={() => handleStockSearch(stockSearchInput)}
              style={{ padding: '0 12px', background: COLORS.accent, border: 'none', color: 'white', borderRadius: 7, cursor: 'pointer', fontSize: '0.85rem' }}>🔍</button>
          </div>

          {stockLoading && <div style={{ textAlign: 'center', color: COLORS.textMuted, fontSize: '0.82rem', padding: '20px 0' }}>Searching…</div>}
          {stockError  && <div style={{ color: '#b91c1c', fontSize: '0.78rem', background: '#fef2f2', padding: '10px', borderRadius: 6, marginBottom: 8 }}>⚠ {stockError}</div>}

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 5 }}>
            {stockResults.map((img, i) => (
              <div key={i}
                onClick={() => onPlaceImage(img.largeImageURL || img.webformatURL)}
                draggable="true"
                onDragStart={e => {
                  const url = img.largeImageURL || img.webformatURL;
                  e.dataTransfer.setData('imageUrl', url);
                  e.dataTransfer.setData('text/plain', url);
                  e.dataTransfer.effectAllowed = 'copy';
                  onDragStart?.(url);
                }}
                onDragEnd={() => onDragEnd?.()}
                title={img.tags} style={tileWrap}
                onMouseEnter={e => { e.currentTarget.style.borderColor = COLORS.accent; e.currentTarget.style.transform = 'scale(1.04)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = COLORS.border; e.currentTarget.style.transform = 'scale(1)'; }}
              >
                <img src={img.previewURL} alt={img.tags}
                  style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', pointerEvents: 'none' }} />
              </div>
            ))}
            {!stockLoading && stockResults.length === 0 && (
              <div style={{ gridColumn: '1/-1', textAlign: 'center', color: COLORS.textMuted, fontSize: '0.82rem', padding: '20px 0' }}>
                Click a category or search above
              </div>
            )}
          </div>
          {stockResults.length > 0 && <div style={{ marginTop: 8, fontSize: '0.72rem', color: COLORS.textFaint, textAlign: 'center' }}>Free images from Pixabay</div>}
        </div>
      )}
    </div>
  );
}
