import React, { useEffect, useState } from 'react';
import { STYLES, COLORS } from '../constants';

const { sectionLabel: sL, input: inp } = STYLES;

// Direct structured editor for the event text fields already drawn onto
// the canvas by canvasBuilder.js (named event_title / event_date /
// event_time / event_desc / temple_addr) — an alternative to double-
// clicking each text object individually.
export default function EventPanel({ fabricRef }) {
  const [title, setTitle]   = useState('');
  const [date, setDate]     = useState('');
  const [time, setTime]     = useState('');
  const [venue, setVenue]   = useState('');
  const [desc, setDesc]     = useState('');

  useEffect(() => {
    const c = fabricRef.current; if (!c) return;
    const get = name => c.getObjects().find(o => o.name === name)?.text || '';
    setTitle(get('event_title'));
    setDate(get('event_date'));
    setTime(get('event_time'));
    setVenue(get('temple_addr'));
    setDesc(get('event_desc'));
  }, [fabricRef]);

  function apply(name, value, setter) {
    setter(value);
    const c = fabricRef.current; if (!c) return;
    const obj = c.getObjects().find(o => o.name === name);
    if (obj) { obj.set('text', value); c.renderAll(); }
  }

  return (
    <div>
      <div style={{ color: COLORS.text, fontWeight: '700', fontSize: '0.95rem', marginBottom: 2 }}>📅 Event</div>
      <div style={{ color: COLORS.textMuted, fontSize: '0.75rem', marginBottom: 12 }}>Edit the text already on your flyer</div>

      <span style={sL}>Title</span>
      <input value={title} onChange={e => apply('event_title', e.target.value, setTitle)} style={{ ...inp, marginBottom: 4 }} />

      <span style={sL}>Date</span>
      <input value={date} onChange={e => apply('event_date', e.target.value, setDate)} style={{ ...inp, marginBottom: 4 }} />

      <span style={sL}>Time</span>
      <input value={time} onChange={e => apply('event_time', e.target.value, setTime)} style={{ ...inp, marginBottom: 4 }} placeholder="e.g. 6:30 PM" />

      <span style={sL}>Venue / Address</span>
      <input value={venue} onChange={e => apply('temple_addr', e.target.value, setVenue)} style={{ ...inp, marginBottom: 4 }} />

      <span style={sL}>Description</span>
      <textarea value={desc} onChange={e => apply('event_desc', e.target.value, setDesc)} rows={4} style={{ ...inp, resize: 'vertical', marginBottom: 4 }} />

      <div style={{ marginTop: 12, padding: '10px 12px', background: COLORS.accentSoft, border: `1px solid ${COLORS.accent}33`, borderRadius: 8, fontSize: '0.7rem', color: COLORS.accent, lineHeight: 1.6 }}>
        💡 You can also double-click any of this text directly on the canvas to edit it in place.
      </div>
    </div>
  );
}
