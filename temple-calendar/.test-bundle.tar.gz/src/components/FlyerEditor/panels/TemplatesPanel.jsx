import React, { useState } from 'react';
import { TEMPLATES, TEMPLATE_CATEGORIES, COLORS } from '../constants';

export default function TemplatesPanel({ onApplyTemplate }) {
  const [cat, setCat] = useState('All');
  const filtered = cat === 'All' ? TEMPLATES : TEMPLATES.filter(t => t.category === cat);

  return (
    <div>
      <div style={{ color: COLORS.text, fontWeight: '700', fontSize: '0.95rem', marginBottom: 2 }}>Templates</div>
      <div style={{ color: COLORS.textMuted, fontSize: '0.75rem', marginBottom: 12 }}>Beautiful starting points for your poster.</div>

      <div style={{ display: 'flex', gap: 5, marginBottom: 14, flexWrap: 'wrap' }}>
        {TEMPLATE_CATEGORIES.map(c => (
          <button key={c} onClick={() => setCat(c)} style={{
            padding: '5px 12px', borderRadius: 20, cursor: 'pointer',
            border: `1.5px solid ${cat === c ? COLORS.accent : COLORS.border}`,
            background: cat === c ? COLORS.accent : '#fff',
            color: cat === c ? '#fff' : COLORS.textMuted,
            fontSize: '0.75rem', fontWeight: cat === c ? '700' : '500',
          }}>{c}</button>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {filtered.map(tpl => (
          <button
            key={tpl.id}
            onClick={() => onApplyTemplate?.(tpl)}
            style={{
              padding: 0, border: `1.5px solid ${COLORS.border}`, borderRadius: 10,
              overflow: 'hidden', cursor: 'pointer', background: '#fff', textAlign: 'left',
              display: 'flex', flexDirection: 'column',
            }}
          >
            <div style={{
              height: 92, position: 'relative',
              background: `linear-gradient(155deg, ${tpl.swatch[0]} 0%, ${tpl.swatch[1]} 60%, ${tpl.swatch[2]} 100%)`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <span style={{ fontSize: '2rem' }}>{tpl.emoji}</span>
            </div>
            <div style={{ padding: '7px 9px' }}>
              <div style={{ color: COLORS.text, fontSize: '0.74rem', fontWeight: '700', lineHeight: 1.25 }}>{tpl.name}</div>
              <div style={{ color: COLORS.textFaint, fontSize: '0.63rem', marginTop: 2 }}>{tpl.category}</div>
            </div>
          </button>
        ))}
      </div>

      <div style={{ marginTop: 14, padding: '10px 12px', background: COLORS.accentSoft, border: `1px solid ${COLORS.accent}33`, borderRadius: 8, fontSize: '0.7rem', color: COLORS.accent, lineHeight: 1.6 }}>
        💡 Applying a template resets the canvas layout — your photo carries over, but repositioned/custom text will not.
      </div>
    </div>
  );
}
