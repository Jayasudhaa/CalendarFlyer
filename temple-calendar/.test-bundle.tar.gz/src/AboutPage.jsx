/**
 * AboutPage - dedicated /about page.
 */
import React from 'react';
import { useNavigate } from 'react-router-dom';
import GlassCard from './GlassCard';
import PremiumButton from './PremiumButton';
import MarketingNav from './components/MarketingNav';
import MarketingFooter from './components/MarketingFooter';

export default function AboutPage() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white">
      <MarketingNav />

      <section className="pt-40 pb-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            About
            <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent"> CalendarFly</span>
          </h1>
          <p className="text-xl text-gray-300 leading-relaxed">
            CalendarFly exists because small organizations, nonprofits, and cultural centers deserve software built for how they actually run — not a generic events tool with a coat of paint.
          </p>
        </div>
      </section>

      <section className="pb-20 px-6">
        <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
          <GlassCard gradient className="p-8">
            <h2 className="text-2xl font-bold mb-3">Our Mission</h2>
            <p className="text-gray-300 leading-relaxed">
              Keep a small organization's or cultural center's calendar, RSVPs and community communication in one place — so admins spend less time on busywork and more time on the community itself.
            </p>
          </GlassCard>
          <GlassCard gradient className="p-8">
            <h2 className="text-2xl font-bold mb-3">How We Got Here</h2>
            <p className="text-gray-300 leading-relaxed">
              Built by working directly with community org admins on what they actually needed: a synced public calendar, real event data, an easy way to broadcast, and a place to track RSVPs — without a steep learning curve.
            </p>
          </GlassCard>
        </div>
      </section>

      <section className="pb-32 px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-center">What we care about</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <GlassCard className="p-6 text-center">
              <div className="text-3xl mb-3">📆</div>
              <div className="font-bold mb-2">Built for community orgs</div>
              <div className="text-gray-400 text-sm">Event types and calendar tools that actually match how small orgs, nonprofits, and cultural centers schedule things.</div>
            </GlassCard>
            <GlassCard className="p-6 text-center">
              <div className="text-3xl mb-3">🤝</div>
              <div className="font-bold mb-2">Easy for volunteers</div>
              <div className="text-gray-400 text-sm">Admin tools simple enough that whoever's running events this month can pick it up quickly.</div>
            </GlassCard>
            <GlassCard className="p-6 text-center">
              <div className="text-3xl mb-3">🔒</div>
              <div className="font-bold mb-2">Your data, your org</div>
              <div className="text-gray-400 text-sm">Each organization's calendar, branding and settings are kept separate on their own subdomain.</div>
            </GlassCard>
          </div>
        </div>
      </section>

      <section className="pb-32 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Have questions about CalendarFly?</h2>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <PremiumButton onClick={() => navigate('/contact')} size="lg" variant="gold">Get in Touch</PremiumButton>
            <PremiumButton onClick={() => navigate('/signup')} size="lg" variant="secondary">Start Free Trial</PremiumButton>
          </div>
        </div>
      </section>

      <MarketingFooter />
    </div>
  );
}
