/**
 * MyProfile - dedicated account page (display name + password)
 * Split out of the old catch-all Settings page so "My Profile" in the
 * account menu goes somewhere that's actually about the person, not the org.
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import AdminToolbar from './components/AdminToolbar';
import { ArrowLeft, User, Lock, Mail, Shield, Building2 } from 'lucide-react';

// Was a warm-gold halo background (radial var(--cf-accent-glow) x3) shared
// across every admin page — dropped in favor of a flat pure-white page
// background (var(--cf-bg-base)) as part of the black & white redesign;
// same fix already applied on the admin calendar page (App.jsx) and
// CalendarGrid.jsx's per-cell tint. The buttons/icon badges below now use
// the glossy black accent from the toolbar and flyer editor instead of
// orange/blue, per the approved "Glossy Black Accents" design option.
const HALO_BG = { backgroundColor: 'var(--cf-bg-base)' };
const GLOSS_BLACK = {
  background: 'linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0) 55%), linear-gradient(135deg,#3a3a3a,#000000)',
  boxShadow: '0 3px 10px -4px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.18)',
};

export default function MyProfile() {
  const navigate = useNavigate();
  const { user, organization, updateProfile, changePassword } = useAuth();

  const [displayName, setDisplayName] = useState('');
  const [nameSaving, setNameSaving] = useState(false);
  const [nameSuccess, setNameSuccess] = useState('');
  const [nameError, setNameError] = useState('');

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwSaving, setPwSaving] = useState(false);
  const [pwSuccess, setPwSuccess] = useState('');
  const [pwError, setPwError] = useState('');

  useEffect(() => {
    if (user) setDisplayName(user.displayName || '');
  }, [user]);

  const handleSaveName = async (e) => {
    e.preventDefault();
    setNameSuccess('');
    setNameError('');
    if (!displayName.trim()) {
      setNameError('Display name cannot be empty');
      return;
    }
    setNameSaving(true);
    const result = await updateProfile({ displayName: displayName.trim() });
    setNameSaving(false);
    if (result.success) {
      setNameSuccess('Profile updated');
      setTimeout(() => setNameSuccess(''), 3000);
    } else {
      setNameError(result.error || 'Failed to update profile');
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    setPwSuccess('');
    setPwError('');
    if (!currentPassword || !newPassword || !confirmPassword) {
      setPwError('Fill in all password fields');
      return;
    }
    if (newPassword.length < 8) {
      setPwError('New password must be at least 8 characters');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPwError('New password and confirmation do not match');
      return;
    }
    setPwSaving(true);
    const result = await changePassword(currentPassword, newPassword);
    setPwSaving(false);
    if (result.success) {
      setPwSuccess('Password changed');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setPwSuccess(''), 3000);
    } else {
      setPwError(result.error || 'Failed to change password');
    }
  };

  return (
    <div className="min-h-screen" style={HALO_BG}>
      <AdminToolbar activePage="profile" />
      {/* Header */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-3xl mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(-1)}
              style={{ ...GLOSS_BLACK, width: 36, height: 36, borderRadius: 8, border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0 }}
            >
              <ArrowLeft className="w-4 h-4" style={{ color: '#fff' }} />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">My Profile</h1>
              <p className="text-sm text-gray-500">Your personal account details</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-3xl mx-auto px-6 py-8 space-y-6">
        {/* Account info (read-only) */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div style={{ ...GLOSS_BLACK, width: 40, height: 40, borderRadius: 9 }} className="flex items-center justify-center">
              <User className="w-5 h-5" style={{ color: '#fff' }} />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-gray-900">Account</h2>
              <p className="text-sm text-gray-500">Basic details tied to your login</p>
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-4 mb-6">
            <div className="p-4 rounded-lg bg-gray-50 border border-gray-200">
              <p className="text-xs text-gray-500 font-semibold flex items-center gap-1.5"><Mail className="w-3.5 h-3.5" /> Email</p>
              <p className="text-sm font-medium text-gray-900 mt-1 break-all">{user?.email || '—'}</p>
            </div>
            <div className="p-4 rounded-lg bg-gray-50 border border-gray-200">
              <p className="text-xs text-gray-500 font-semibold flex items-center gap-1.5"><Shield className="w-3.5 h-3.5" /> Role</p>
              <p className="text-sm font-medium text-gray-900 mt-1 capitalize">{user?.role || '—'}</p>
            </div>
            <div className="p-4 rounded-lg bg-gray-50 border border-gray-200 sm:col-span-2">
              <p className="text-xs text-gray-500 font-semibold flex items-center gap-1.5"><Building2 className="w-3.5 h-3.5" /> Organization</p>
              <p className="text-sm font-medium text-gray-900 mt-1">{organization?.name || '—'}</p>
            </div>
          </div>

          {nameSuccess && (
            <div className="mb-4 p-3 rounded-lg bg-green-50 border border-green-200 text-green-700 text-sm">{nameSuccess}</div>
          )}
          {nameError && (
            <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">{nameError}</div>
          )}
          <form onSubmit={handleSaveName} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Display Name</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-black"
                placeholder="Your name"
              />
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={nameSaving}
                style={{ ...GLOSS_BLACK, opacity: nameSaving ? 0.6 : 1, border: 'none', cursor: nameSaving ? 'not-allowed' : 'pointer' }}
                className="px-5 py-2.5 rounded-lg text-white font-semibold text-sm"
              >
                {nameSaving ? 'Saving…' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>

        {/* Change password */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div style={{ ...GLOSS_BLACK, width: 40, height: 40, borderRadius: 9 }} className="flex items-center justify-center">
              <Lock className="w-5 h-5" style={{ color: '#fff' }} />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-gray-900">Password</h2>
              <p className="text-sm text-gray-500">Change the password used to log in</p>
            </div>
          </div>

          {pwSuccess && (
            <div className="mb-4 p-3 rounded-lg bg-green-50 border border-green-200 text-green-700 text-sm">{pwSuccess}</div>
          )}
          {pwError && (
            <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">{pwError}</div>
          )}
          <form onSubmit={handleChangePassword} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Current Password</label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-black"
                autoComplete="current-password"
              />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">New Password</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-black"
                  autoComplete="new-password"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Confirm New Password</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-black"
                  autoComplete="new-password"
                />
              </div>
            </div>
            <p className="text-xs text-gray-500">Must be at least 8 characters.</p>
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={pwSaving}
                style={{ ...GLOSS_BLACK, opacity: pwSaving ? 0.6 : 1, border: 'none', cursor: pwSaving ? 'not-allowed' : 'pointer' }}
                className="px-5 py-2.5 rounded-lg text-white font-semibold text-sm"
              >
                {pwSaving ? 'Updating…' : 'Change Password'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
