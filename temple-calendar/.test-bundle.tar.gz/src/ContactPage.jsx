/**
 * ContactPage - dedicated /contact page with a real form.
 * Submits to POST /api/contact, which sends an email via AWS SES
 * (see server/routes/contact.js) — no database storage, per the site
 * owner's choice to have submissions delivered straight to their inbox.
 */
import React, { useState } from 'react';
import GlassCard from './GlassCard';
import PremiumButton from './PremiumButton';
import MarketingNav from './components/MarketingNav';
import MarketingFooter from './components/MarketingFooter';

const TOPICS = ['General question', 'Sales', 'Support', 'Partnership', 'Careers'];

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', email: '', topic: TOPICS[0], message: '' });
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState(null); // { ok: bool, message: string }

  const update = (field) => (e) => setForm(f => ({ ...f, [field]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setResult(null);
    if (!form.name.trim() || !form.email.trim() || !form.message.trim()) {
      setResult({ ok: false, message: 'Please fill in your name, email, and message.' });
      return;
    }
    setSending(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to send message');
      setResult({ ok: true, message: "Thanks — your message is on its way. We'll get back to you soon." });
      setForm({ name: '', email: '', topic: TOPICS[0], message: '' });
    } catch (err) {
      setResult({ ok: false, message: err.message || 'Something went wrong sending your message. Please try again.' });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white">
      <MarketingNav />

      <section className="pt-40 pb-32 px-6">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-10">
            <h1 className="text-5xl font-bold mb-4">
              Get in
              <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent"> Touch</span>
            </h1>
            <p className="text-gray-300">Questions about CalendarFly, pricing, or your organization's setup? Send us a note.</p>
          </div>

          <GlassCard gradient className="p-8">
            {result && (
              <div className={`mb-6 rounded-lg px-4 py-3 text-sm ${result.ok ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-200' : 'bg-red-500/15 border border-red-500/40 text-red-200'}`}>
                {result.message}
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">Name</label>
                  <input
                    type="text" value={form.name} onChange={update('name')}
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/15 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">Email</label>
                  <input
                    type="email" value={form.email} onChange={update('email')}
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/15 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    placeholder="you@example.com"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Topic</label>
                <select
                  value={form.topic} onChange={update('topic')}
                  className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/15 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                  {TOPICS.map(t => <option key={t} value={t} className="bg-gray-900">{t}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Message</label>
                <textarea
                  value={form.message} onChange={update('message')}
                  rows={5}
                  className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/15 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                  placeholder="How can we help?"
                />
              </div>
              <PremiumButton type="submit" fullWidth variant="gold" disabled={sending}>
                {sending ? 'Sending…' : 'Send Message'}
              </PremiumButton>
            </form>
          </GlassCard>
        </div>
      </section>

      <MarketingFooter />
    </div>
  );
}
