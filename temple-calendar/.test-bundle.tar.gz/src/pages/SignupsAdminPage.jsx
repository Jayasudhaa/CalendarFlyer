/**
 * src/pages/SignupsAdminPage.jsx
 * Route: /signups-admin
 *
 * Admin home for the Sign-Up Sheets feature (server/routes/signups.js) --
 * create Volunteer-shift or Potluck-dish sheets against an event, watch
 * slots fill up (with waitlists once a slot's full), and pull the
 * volunteer-hours report. Same page shell/auth pattern as
 * PhotoModerationPage.jsx: AdminToolbar + useAuth's token for the
 * admin-only /api/signups/* routes.
 */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useEvents } from '../hooks/useEvents';
import { useAuth } from '../contexts/AuthContext';
import AdminToolbar from '../components/AdminToolbar';
import { getSignupUrl } from '../utils/rsvpUrl';
import { playSuccess } from '../utils/sound';
import { getDefaultSignupType, SHEET_TYPE_LABELS } from '../utils/signupTemplates';

const HALO_BG = { backgroundColor: 'var(--cf-bg-base)' };

function authHeaders() {
  const token = localStorage.getItem('cf_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function blankSlot(type) {
  return type === 'volunteer'
    ? { label: '', time_label: '', hours: '', capacity: 3 }
    : { label: '', capacity: 4 };
}

function fmtHours(h) {
  const n = Math.round(h * 10) / 10;
  return `${n} hr${n === 1 ? '' : 's'}`;
}

export default function SignupsAdminPage() {
  const navigate = useNavigate();
  const { events } = useEvents();
  const { organization } = useAuth();
  const [tab, setTab] = useState('sheets'); // 'sheets' | 'hours'

  const [sheets, setSheets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);

  const [showCreate, setShowCreate] = useState(false);
  const [eventId, setEventId] = useState('');
  const [type, setType] = useState('volunteer');
  const [title, setTitle] = useState('');
  const [titleTouched, setTitleTouched] = useState(false);
  const [slots, setSlots] = useState([blankSlot('volunteer')]);
  const [earlyAccessHours, setEarlyAccessHours] = useState('0');
  const [saving, setSaving] = useState(false);
  const [createError, setCreateError] = useState('');

  const [hours, setHours] = useState(null);
  const [hoursLoading, setHoursLoading] = useState(false);

  const defaultType = useMemo(() => getDefaultSignupType(organization?.category), [organization]);

  const loadSheets = useCallback(async () => {
    try {
      const res = await fetch('/api/signups/sheets', { headers: { ...authHeaders() } });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to load sign-up sheets');
      setSheets(data.sheets || []);
      setError('');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadSheets(); }, [loadSheets]);

  // Full sheet detail (slots + roster) is only fetched for sheets actually
  // shown expanded -- the /sheets list above is metadata-only.
  const [detail, setDetail] = useState({}); // sheet_id -> full sheet view
  const [expanded, setExpanded] = useState({}); // sheet_id -> bool

  const loadDetail = async (sheet_id) => {
    try {
      const res = await fetch(`/api/signups/sheets/${sheet_id}`, { headers: { ...authHeaders() } });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to load that sheet');
      setDetail((prev) => ({ ...prev, [sheet_id]: data.sheet }));
    } catch (err) {
      setError(err.message);
    }
  };

  const toggleExpand = (sheet_id) => {
    setExpanded((prev) => ({ ...prev, [sheet_id]: !prev[sheet_id] }));
    if (!detail[sheet_id]) loadDetail(sheet_id);
  };

  const eventById = useMemo(() => {
    const m = new Map();
    events.forEach((e) => m.set(e.id, e));
    return m;
  }, [events]);

  const upcomingEvents = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    return [...events].filter((e) => e.date >= today).sort((a, b) => a.date.localeCompare(b.date));
  }, [events]);

  // ── Create form ──────────────────────────────────────────────────────

  const openCreate = () => {
    setType(defaultType);
    setSlots([blankSlot(defaultType)]);
    setEventId(upcomingEvents[0]?.id || '');
    setTitle('');
    setTitleTouched(false);
    setEarlyAccessHours('0');
    setCreateError('');
    setShowCreate(true);
  };

  useEffect(() => {
    if (!showCreate || titleTouched) return;
    const ev = eventById.get(eventId);
    if (!ev) return;
    setTitle(`${ev.title} — ${SHEET_TYPE_LABELS[type].label}`);
  }, [eventId, type, showCreate, titleTouched, eventById]);

  const setSlotField = (i, field, value) => {
    setSlots((prev) => prev.map((s, idx) => (idx === i ? { ...s, [field]: value } : s)));
  };
  const addSlot = () => setSlots((prev) => [...prev, blankSlot(type)]);
  const removeSlot = (i) => setSlots((prev) => prev.filter((_, idx) => idx !== i));
  const switchType = (t) => { setType(t); setSlots([blankSlot(t)]); };

  const submitCreate = async () => {
    setCreateError('');
    if (!eventId) return setCreateError('Pick an event.');
    if (!title.trim()) return setCreateError('Give this sheet a title.');
    const cleanSlots = slots
      .map((s) => ({
        label: (s.label || '').trim(),
        capacity: Math.max(1, parseInt(s.capacity, 10) || 1),
        time_label: type === 'volunteer' ? (s.time_label || '').trim() : undefined,
        duration_minutes: type === 'volunteer' ? Math.round((parseFloat(s.hours) || 0) * 60) : undefined,
      }))
      .filter((s) => s.label);
    if (cleanSlots.length === 0) return setCreateError(`Add at least one ${SHEET_TYPE_LABELS[type].slotNoun}.`);

    setSaving(true);
    try {
      const ev = eventById.get(eventId);
      const res = await fetch('/api/signups/sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ event_id: eventId, type, title: title.trim(), event_date: ev?.date, slots: cleanSlots, early_access_hours: parseInt(earlyAccessHours, 10) || 0 }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Could not create that sheet.');
      setShowCreate(false);
      await loadSheets();
      playSuccess();
    } catch (err) {
      setCreateError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const removeSheet = async (sheet_id) => {
    if (!window.confirm('Delete this sign-up sheet? Everyone already signed up will be removed too.')) return;
    setBusyId(sheet_id);
    try {
      const res = await fetch(`/api/signups/sheets/${sheet_id}`, { method: 'DELETE', headers: { ...authHeaders() } });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Could not delete that sheet.');
      setSheets((prev) => prev.filter((s) => s.sheet_id !== sheet_id));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  };

  const copyLink = async (event) => {
    if (!event) return;
    try { await navigator.clipboard.writeText(getSignupUrl(event)); } catch { /* clipboard unavailable */ }
  };

  // "Announce this sheet" — hands a ready-made caption off to Broadcast
  // (the top-level nav page, not the per-flyer modal) instead of trying to
  // send anything itself. Broadcast only exists as an overlay on /admin, so
  // this reuses the same pendingAction handoff every other page already
  // uses to open it (see App.jsx's location.state.pendingAction effect) —
  // just with an extra broadcastCaption alongside it for Broadcast to
  // preload into its message box. Nothing is sent automatically; the admin
  // still picks channels and hits Send on the Broadcast page themselves.
  const announceSheet = (sheet, event) => {
    if (!event) return;
    const typeLabel = SHEET_TYPE_LABELS[sheet.type]?.label || 'Sign-Up Sheet';
    const caption = `🙋 ${typeLabel} — ${event.title}
📅 ${sheet.event_date}

Spots are open — sign up here: ${getSignupUrl(event)}`;
    navigate('/admin', { state: { pendingAction: 'broadcast', broadcastCaption: caption } });
  };

  // ── Volunteer hours ──────────────────────────────────────────────────

  const loadHours = useCallback(async () => {
    setHoursLoading(true);
    try {
      const res = await fetch('/api/signups/volunteer-hours', { headers: { ...authHeaders() } });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to load the volunteer-hours report');
      setHours(data.members || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setHoursLoading(false);
    }
  }, []);

  useEffect(() => { if (tab === 'hours' && hours === null) loadHours(); }, [tab, hours, loadHours]);


  const exportHoursCsv = () => {
    const rows = [['Name', 'Total Hours', 'Shifts'], ...(hours || []).map((m) => [m.member_name, m.total_hours, m.shifts_count])];
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'volunteer-hours.csv';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const tabBtn = (key, label) => (
    <button onClick={() => setTab(key)} style={{
      padding: '9px 16px', borderRadius: 8, border: '1px solid var(--cf-border)',
      background: tab === key ? 'var(--cf-text-primary)' : 'var(--cf-bg-surface)',
      color: tab === key ? '#fff' : 'var(--cf-text-secondary)',
      fontWeight: 700, fontSize: '0.82rem', cursor: 'pointer',
    }}>{label}</button>
  );

  return (
    <div style={{ minHeight: '100vh', ...HALO_BG }}>
      <AdminToolbar activePage="signups" />
      <div style={{ padding: 20 }}>
        <div style={{ maxWidth: 1100, margin: '0 auto' }}>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12, marginBottom: 20 }}>
            <div>
              <div style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--cf-text-primary)', fontFamily: "'Playfair Display', Georgia, serif" }}>
                Sign-Ups
              </div>
              <div style={{ color: 'var(--cf-text-muted)', fontSize: '0.85rem', marginTop: 4 }}>
                Volunteer shifts and potluck dishes, coordinated in one place.
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              {tabBtn('sheets', '📋 Sign-Up Sheets')}
              {tabBtn('hours', '⏱️ Volunteer Hours')}
            </div>
          </div>

          {error && (
            <div style={{ marginBottom: 16, padding: '10px 14px', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 8, color: '#dc2626', fontSize: '0.85rem' }}>
              {error}
            </div>
          )}

          {tab === 'sheets' && (
            <>
              <div style={{ marginBottom: 18 }}>
                {!showCreate ? (
                  <button onClick={openCreate} style={{
                    padding: '10px 16px', borderRadius: 8, border: 'none', background: 'var(--cf-btn-bg)',
                    color: '#fff', fontWeight: 700, fontSize: '0.85rem', cursor: 'pointer',
                  }}>+ New Sign-Up Sheet</button>
                ) : (
                  <div style={{ background: 'var(--cf-bg-surface)', border: '1px solid var(--cf-border)', borderRadius: 12, padding: 18 }}>
                    <div style={{ fontWeight: 800, fontSize: '1rem', color: 'var(--cf-text-primary)', marginBottom: 14, fontFamily: "'Playfair Display', Georgia, serif" }}>New Sign-Up Sheet</div>

                    <div style={{ display: 'flex', gap: 10, marginBottom: 12, flexWrap: 'wrap' }}>
                      {['volunteer', 'potluck'].map((t) => (
                        <button key={t} onClick={() => switchType(t)} style={{
                          padding: '9px 14px', borderRadius: 8, cursor: 'pointer', fontSize: '0.82rem', fontWeight: 700,
                          border: type === t ? '1.5px solid var(--cf-accent)' : '1px solid var(--cf-border)',
                          background: type === t ? 'rgba(146,64,14,0.08)' : 'var(--cf-bg-base)',
                          color: type === t ? 'var(--cf-accent)' : 'var(--cf-text-secondary)',
                        }}>{SHEET_TYPE_LABELS[t].icon} {SHEET_TYPE_LABELS[t].label}</button>
                      ))}
                      <span style={{ fontSize: '0.72rem', color: 'var(--cf-text-muted)', alignSelf: 'center' }}>
                        {defaultType === type ? '(default for your org type)' : ''}
                      </span>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
                      <div>
                        <label style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--cf-text-muted)', display: 'block', marginBottom: 4 }}>Event</label>
                        <select value={eventId} onChange={(e) => setEventId(e.target.value)} style={inputStyle}>
                          <option value="">Select an event…</option>
                          {upcomingEvents.map((e) => <option key={e.id} value={e.id}>{e.title} — {e.date}</option>)}
                        </select>
                      </div>
                      <div>
                        <label style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--cf-text-muted)', display: 'block', marginBottom: 4 }}>Sheet title</label>
                        <input value={title} onChange={(e) => { setTitle(e.target.value); setTitleTouched(true); }} style={inputStyle} />
                      </div>
                    </div>

                    <div style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--cf-text-muted)', marginBottom: 6 }}>
                      {type === 'volunteer' ? 'Shifts' : 'Dish categories'}
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 10 }}>
                      {slots.map((s, i) => (
                        <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                          <input placeholder={type === 'volunteer' ? 'e.g. Setup Crew' : 'e.g. Rice Items'} value={s.label} onChange={(e) => setSlotField(i, 'label', e.target.value)} style={{ ...inputStyle, flex: 2, minWidth: 140 }} />
                          {type === 'volunteer' && (
                            <>
                              <input placeholder="e.g. 8:00 – 9:30 AM" value={s.time_label} onChange={(e) => setSlotField(i, 'time_label', e.target.value)} style={{ ...inputStyle, flex: 2, minWidth: 140 }} />
                              <input type="number" min="0" step="0.5" placeholder="Hours" value={s.hours} onChange={(e) => setSlotField(i, 'hours', e.target.value)} style={{ ...inputStyle, width: 80 }} />
                            </>
                          )}
                          <input type="number" min="1" placeholder="Capacity" value={s.capacity} onChange={(e) => setSlotField(i, 'capacity', e.target.value)} style={{ ...inputStyle, width: 90 }} />
                          <button onClick={() => removeSlot(i)} disabled={slots.length === 1} style={{ background: 'none', border: 'none', color: slots.length === 1 ? 'var(--cf-text-muted)' : '#dc2626', cursor: slots.length === 1 ? 'default' : 'pointer', fontSize: '1rem', padding: 4 }}>✕</button>
                        </div>
                      ))}
                    </div>
                    <button onClick={addSlot} style={{ background: 'none', border: 'none', color: 'var(--cf-accent)', fontWeight: 700, fontSize: '0.8rem', cursor: 'pointer', padding: 0, marginBottom: 16 }}>+ Add {SHEET_TYPE_LABELS[type].slotNoun}</button>

                    <div style={{ marginBottom: 16 }}>
                      <label style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--cf-text-muted)', display: 'block', marginBottom: 4 }}>
                        👥 Early access for followers
                      </label>
                      <select value={earlyAccessHours} onChange={(e) => setEarlyAccessHours(e.target.value)} style={inputStyle}>
                        <option value="0">Off — open to everyone right away</option>
                        <option value="24">24 hours before opening to everyone</option>
                        <option value="48">48 hours before opening to everyone</option>
                        <option value="72">72 hours before opening to everyone</option>
                      </select>
                      <div style={{ fontSize: '0.7rem', color: 'var(--cf-text-muted)', marginTop: 4 }}>
                        People who follow your temple can join this sheet immediately; everyone else has to wait out this window.
                      </div>
                    </div>

                    {createError && <div style={{ marginBottom: 10, color: '#dc2626', fontSize: '0.8rem' }}>{createError}</div>}

                    <div style={{ display: 'flex', gap: 8 }}>
                      <button onClick={submitCreate} disabled={saving} style={{ padding: '9px 16px', borderRadius: 8, border: 'none', background: 'var(--cf-btn-bg)', color: '#fff', fontWeight: 700, fontSize: '0.85rem', cursor: saving ? 'default' : 'pointer' }}>
                        {saving ? 'Creating…' : 'Create Sheet'}
                      </button>
                      <button onClick={() => setShowCreate(false)} style={{ padding: '9px 16px', borderRadius: 8, border: '1px solid var(--cf-border)', background: 'var(--cf-bg-base)', color: 'var(--cf-text-secondary)', fontWeight: 700, fontSize: '0.85rem', cursor: 'pointer' }}>Cancel</button>
                    </div>
                  </div>
                )}
              </div>

              {loading ? (
                <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--cf-text-muted)' }}>⏳ Loading…</div>
              ) : sheets.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--cf-text-muted)' }}>No sign-up sheets yet — create one above.</div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {sheets.map((s) => {
                    const ev = eventById.get(s.event_id);
                    const d = detail[s.sheet_id];
                    const isOpen = !!expanded[s.sheet_id];
                    return (
                      <div key={s.sheet_id} style={{ background: 'var(--cf-bg-surface)', border: '1px solid var(--cf-border)', borderRadius: 12, overflow: 'hidden' }}>
                        <div onClick={() => toggleExpand(s.sheet_id)} style={{ padding: '14px 18px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', gap: 10, flexWrap: 'wrap' }}>
                          <div>
                            <div style={{ fontWeight: 700, fontSize: '0.92rem', color: 'var(--cf-text-primary)' }}>
                              {SHEET_TYPE_LABELS[s.type]?.icon} {s.title}
                            </div>
                            <div style={{ color: 'var(--cf-text-muted)', fontSize: '0.76rem', marginTop: 2 }}>
                              {ev ? ev.title : 'Unknown event'} · {s.event_date}
                            </div>
                          </div>
                          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                            <button onClick={(e) => { e.stopPropagation(); copyLink(ev); }} disabled={!ev} style={smallBtnStyle}>🔗 Copy link</button>
                            <button onClick={(e) => { e.stopPropagation(); announceSheet(s, ev); }} disabled={!ev} style={smallBtnStyle}>📣 Announce</button>
                            <button onClick={(e) => { e.stopPropagation(); removeSheet(s.sheet_id); }} disabled={busyId === s.sheet_id} style={{ ...smallBtnStyle, color: '#dc2626', borderColor: 'rgba(220,38,38,0.3)' }}>🗑</button>
                            <span style={{ color: 'var(--cf-text-muted)', fontSize: '0.8rem' }}>{isOpen ? '▲' : '▼'}</span>
                          </div>
                        </div>
                        {isOpen && (
                          <div style={{ borderTop: '1px solid var(--cf-border)', padding: '12px 18px' }}>
                            {!d ? (
                              <div style={{ color: 'var(--cf-text-muted)', fontSize: '0.82rem' }}>Loading…</div>
                            ) : (
                              d.slots.map((slot) => (
                                <div key={slot.slot_id} style={{ padding: '10px 0', borderBottom: '1px solid var(--cf-bg-deep)' }}>
                                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                                    <div>
                                      <span style={{ fontWeight: 700, fontSize: '0.86rem', color: 'var(--cf-text-primary)' }}>{slot.label}</span>
                                      {slot.time_label && <span style={{ color: 'var(--cf-text-muted)', fontSize: '0.76rem', marginLeft: 8 }}>🕐 {slot.time_label}</span>}
                                    </div>
                                    <span style={{ fontSize: '0.78rem', fontWeight: 700, color: slot.confirmed.length >= slot.capacity ? '#16a34a' : 'var(--cf-accent)' }}>
                                      {slot.confirmed.length} / {slot.capacity}
                                    </span>
                                  </div>
                                  {slot.confirmed.length > 0 && (
                                    <div style={{ marginTop: 6, fontSize: '0.78rem', color: 'var(--cf-text-secondary)' }}>
                                      {slot.confirmed.map((e) => e.name + (e.dish ? ` (${e.dish})` : '')).join(', ')}
                                    </div>
                                  )}
                                  {slot.waitlist.length > 0 && (
                                    <div style={{ marginTop: 4, fontSize: '0.76rem', color: '#b45309' }}>
                                      ⏳ Waitlist ({slot.waitlist.length}): {slot.waitlist.map((e) => e.name).join(', ')}
                                    </div>
                                  )}
                                  {slot.confirmed.length === 0 && slot.waitlist.length === 0 && (
                                    <div style={{ marginTop: 4, fontSize: '0.76rem', color: 'var(--cf-text-muted)', fontStyle: 'italic' }}>No one yet</div>
                                  )}
                                </div>
                              ))
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {tab === 'hours' && (
            <div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 10 }}>
                <button onClick={exportHoursCsv} disabled={!hours || hours.length === 0} style={smallBtnStyle}>⬇ Export CSV</button>
              </div>
              {hoursLoading ? (
                <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--cf-text-muted)' }}>⏳ Loading…</div>
              ) : !hours || hours.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--cf-text-muted)' }}>No confirmed volunteer shifts yet.</div>
              ) : (
                <div style={{ background: 'var(--cf-bg-surface)', border: '1px solid var(--cf-border)', borderRadius: 12, overflow: 'hidden' }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 120px 100px', padding: '10px 16px', fontSize: '0.72rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--cf-text-muted)', borderBottom: '1px solid var(--cf-border)' }}>
                    <span>Name</span><span>Hours</span><span>Shifts</span>
                  </div>
                  {hours.map((m) => (
                    <div key={m.member_id} style={{ display: 'grid', gridTemplateColumns: '1fr 120px 100px', padding: '10px 16px', fontSize: '0.85rem', borderBottom: '1px solid var(--cf-bg-deep)' }}>
                      <span style={{ color: 'var(--cf-text-primary)', fontWeight: 600 }}>{m.member_name}</span>
                      <span style={{ color: 'var(--cf-accent)', fontWeight: 700 }}>{fmtHours(m.total_hours)}</span>
                      <span style={{ color: 'var(--cf-text-muted)' }}>{m.shifts_count}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

const inputStyle = {
  width: '100%', padding: '8px 10px', boxSizing: 'border-box',
  background: 'var(--cf-bg-base)', border: '1px solid var(--cf-border)',
  borderRadius: 7, color: 'var(--cf-text-primary)', fontSize: '0.84rem',
};

const smallBtnStyle = {
  padding: '6px 10px', borderRadius: 7, border: '1px solid var(--cf-border)',
  background: 'var(--cf-bg-base)', color: 'var(--cf-text-secondary)',
  fontSize: '0.76rem', fontWeight: 700, cursor: 'pointer',
};
