/**
 * AuthContext - UPDATED with calendar redirect
 */

import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [organization, setOrganization] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('cf_token');
    const savedUser = localStorage.getItem('cf_user');
    const savedOrg = localStorage.getItem('cf_org');

    if (token && savedUser && savedOrg) {
      setUser(JSON.parse(savedUser));
      setOrganization(JSON.parse(savedOrg));
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      if (!response.ok) {
        // Unverified-email accounts get a distinct flag (plus the email
        // address) so the login screen can offer a "resend" action instead
        // of just showing a dead-end error.
        return { success: false, error: data.error || 'Login failed', needsVerification: !!data.needsVerification, email: data.email };
      }

      localStorage.setItem('cf_token', data.token);
      localStorage.setItem('cf_user', JSON.stringify(data.user));
      localStorage.setItem('cf_org', JSON.stringify(data.organization));
      setUser(data.user);
      setOrganization(data.organization);
      return { success: true, organization: data.organization };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  // Signs in with a Google ID token (the `credential` from the frontend's
  // GoogleLogin button — see components/GoogleLoginButton.jsx). The server
  // verifies it, signs a/an existing account in, or creates a brand-new
  // organization for a first-time email — see POST /api/auth/google in
  // server/routes/auth.js for what actually decides that. Same response
  // shape as login(), so it's stored the same way.
  const loginWithGoogle = async (credential) => {
    try {
      const response = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ credential }),
      });

      const data = await response.json();
      if (!response.ok) {
        return { success: false, error: data.error || 'Google sign-in failed' };
      }

      localStorage.setItem('cf_token', data.token);
      localStorage.setItem('cf_user', JSON.stringify(data.user));
      localStorage.setItem('cf_org', JSON.stringify(data.organization));
      setUser(data.user);
      setOrganization(data.organization);
      return { success: true, organization: data.organization };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  // Signup no longer returns a login token — the account is created
  // unverified and the server emails a verification link (see
  // routes/auth.js). Nothing to store here or log the user into; the
  // caller (PremiumSignup.jsx) shows a "check your email" screen using
  // the returned email/message instead of navigating into the app.
  const signup = async (formData) => {
    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Signup failed');
      }
      return { success: true, needsVerification: true, email: data.email, message: data.message, emailSendFailed: data.emailSendFailed };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  // Resends the verification email — used from both the post-signup
  // confirmation screen and the "email not verified" state on the login
  // page. Always resolves success (the server intentionally never reveals
  // whether an address exists or was already verified).
  const resendVerification = async (email) => {
    try {
      await fetch('/api/auth/resend-verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  function logout() {
    localStorage.removeItem('cf_token');
    localStorage.removeItem('cf_user');
    localStorage.removeItem('cf_org');
    // Clear flyer studio data on logout
    localStorage.removeItem('flyer_studio_data');
    setUser(null);
    setOrganization(null);
  };

  const updateOrganization = async (updates) => {
    try {
      const token = localStorage.getItem('cf_token');
      const response = await fetch('/api/organizations/settings', {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(updates),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Update failed');
      }
      const updatedOrg = data.organization;
      localStorage.setItem('cf_org', JSON.stringify(updatedOrg));
      setOrganization(updatedOrg);
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  const updateProfile = async (updates) => {
    try {
      const token = localStorage.getItem('cf_token');
      const response = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(updates),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Update failed');
      }
      const updatedUser = data.user;
      localStorage.setItem('cf_user', JSON.stringify(updatedUser));
      setUser(updatedUser);
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  const changePassword = async (currentPassword, newPassword) => {
    try {
      const token = localStorage.getItem('cf_token');
      const response = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to change password');
      }
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  const value = {
    user,
    organization,
    loading,
    isAuthenticated: !!user,
    login,
    loginWithGoogle,
    signup,
    resendVerification,
    logout,
    updateOrganization,
    updateProfile,
    changePassword,
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );

  }

