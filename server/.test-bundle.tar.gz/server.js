/**
 * server/server.js
 * Express backend for Temple Calendar
 */
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const cors = require('cors');
const helmet = require('helmet');
const path = require('path');
const { tenantMiddleware } = require('./middleware/tenant');


const app = express();
const PORT = process.env.PORT || 5000;

// Baseline security headers (X-Content-Type-Options, X-Frame-Options,
// Strict-Transport-Security, etc.) — there were none before this. CSP and
// Cross-Origin-Resource-Policy are turned off explicitly rather than left
// at helmet's strict defaults: this same server serves the built React
// frontend in production (see the PRODUCTION BUILD block below), which
// loads Google Fonts, S3-hosted images/flyers, and proxies external
// images through /api/image-proxy with explicit permissive CORS headers —
// helmet's default CSP would likely block some of that, and getting a
// correct CSP allowlist for every asset source this app uses is a
// separate, more careful pass rather than something to guess at here.
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: false, crossOriginEmbedderPolicy: false }));

// ✅ Keep only required frontend domains
const allowedOrigins = [
  'https://calendarflyapp.com',
  'https://www.calendarflyapp.com',
  'http://localhost:5173',
  'http://localhost:3000',
  process.env.FRONTEND_URL,
].filter(Boolean);

// ✅ CENTRAL CORS CONFIG (used for BOTH normal + preflight)
const corsOptions = {
  origin: (origin, cb) => {
    if (!origin) return cb(null, true);

    if (allowedOrigins.includes(origin)) return cb(null, true);

    if (origin.endsWith('.calendarflyapp.com')) return cb(null, true);

    console.warn(`[CORS] Blocked: ${origin}`);
    return cb(new Error(`CORS blocked: ${origin}`));
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-admin-secret'],
  credentials: true,
};

// ✅ FIX: apply SAME config to OPTIONS (preflight)
app.use(cors(corsOptions));
app.options('*', cors(corsOptions));

// Stripe webhook — MUST be mounted with the raw (unparsed) body, and MUST
// come before the global express.json() below. Stripe's signature check
// (see handleStripeWebhook in routes/billing.js) hashes the exact raw
// bytes of the request; once express.json() has parsed and re-serialized
// the body, the signature no longer matches and every webhook call fails
// verification.
app.post('/api/billing/webhook', express.raw({ type: 'application/json' }), require('./routes/billing').handleStripeWebhook);

app.use(express.json({ limit: '25mb' }));

app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 7 * 24 * 60 * 60 * 1000,
    sameSite: 'lax'
  }
}));

// ── MULTI-TENANT ─────────────────────────────────────────
app.use(tenantMiddleware);
app.use((req, res, next) => {
  if (req.org) {
    console.log(`[TENANT] ${req.method} ${req.path} → ${req.org.name}`);
  }
  next();
});

// ── AUTH ─────────────────────────────────────────────────
const authRoutes = require('./routes/auth');
app.use('/api/auth', authRoutes);

app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;

  if (username === process.env.ADMIN_USERNAME && password === process.env.ADMIN_PASSWORD) {
    req.session.isAuthenticated = true;
    req.session.user = { username, displayName: 'Site Admin' };
    return res.json({ success: true, user: req.session.user });
  }

  return res.status(401).json({ success: false, error: 'Invalid credentials' });
});

app.post('/api/admin/logout', (req, res) => {
  req.session.destroy(() => res.json({ success: true }));
});

app.get('/api/admin/status', (req, res) => {
  if (req.session?.isAuthenticated) {
    return res.json({ authenticated: true, user: req.session.user });
  }
  return res.json({ authenticated: false });
});

// ── ROUTES ───────────────────────────────────────────────
app.use('/api/organizations', require('./routes/organizations'));
app.use('/api/billing', require('./routes/billing'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/events', require('./routes/events'));
app.use('/api', require('./routes/generate-image'));
app.use('/api', require('./routes/rsvp'));
app.use('/api', require('./routes/pixabay'));
app.use('/api', require('./routes/translate'));
app.use('/api', require('./routes/imageLibrary'));
app.use('/api', require('./routes/image-proxy'));
app.use('/api/flyers', require('./routes/flyerRoutes'));
app.use('/api/broadcast', require('./routes/broadcast'));
// "Connect with Facebook / Instagram / WhatsApp" OAuth flows for
// Organization Settings — see routes/social-connect.js's file header.
app.use('/api/social', require('./routes/social-connect'));
// Live community photo album for events: phone-OTP devotee identity
// (public, unauthenticated on purpose — see routes/community.js's file
// header) and the photo upload/moderation/album routes that ride on top
// of it (community-member-authenticated, plus a couple of admin-only
// moderation routes — see routes/photos.js's file header).
app.use('/api/community', require('./routes/community'));
app.use('/api/photos', require('./routes/photos'));
app.use('/api/signups', require('./routes/signups'));
app.use('/api/remove-bg', require('./routes/remove-bg'));
app.use('/api/contact', require('./routes/contact'));
app.use('/api/image-feedback', require('./routes/image-feedback'));
// Conversational chatbot only (admin assistant + public temple/org bot).
// The DynamoDB/S3 event-sync routes that used to live in the same file are
// intentionally NOT mounted — see server/routes/eventSync.js for why.
app.use('/api/chat', require('./routes/chat'));


// ── HEALTH ───────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    org: req.org ? req.org.name : 'none'
  });
});

// ── PRODUCTION BUILD ─────────────────────────────────────
if (process.env.NODE_ENV === 'production') {
  const buildPath = path.join(__dirname, 'dist-frontend');
  app.use(express.static(buildPath));
  app.get('*', (req, res) =>
    res.sendFile(path.join(buildPath, 'index.html'))
  );
}

// ── START ────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`✓ Server running on ${PORT}`);
  // Broadcast page "Schedule for later" — see scheduler.js's file header
  // for why this is an in-process poll rather than a real queue. Started
  // only once the server is actually listening, not at module load, so a
  // crash during startup doesn't leave an orphaned interval behind.
  require('./scheduler').start();
});