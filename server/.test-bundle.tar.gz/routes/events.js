/**
 * server/routes/events.js
 * Events API — uses existing calendarfly_events DynamoDB table
 *
 * Table schema:
 *   PK: event_id (String)
 *   GSI: org-index → org_id (String)
 *
 * Routes:
 *   GET  /api/events/upcoming   — PUBLIC, used by chatbot Lambda
 *   POST /api/events/sync       — bulk sync from frontend → DynamoDB (admin)
 *   POST /api/events            — add single event (admin)
 *   DELETE /api/events/:eventId — delete event (admin)
 */

const express = require('express');
const router  = express.Router();
const { createEvent, getEventsByOrg, updateEvent, deleteEvent } = require('../events');
const { authenticateToken } = require('./auth');

// Resolves org_id for this request: prefer a logged-in user's org (JWT),
// fall back to the subdomain-resolved org (req.org, for public visitors).
// This lets the admin dashboard work on the bare domain while logged in,
function resolveOrgId(req) {
  if (req.user && req.user.org_id) return req.user.org_id;
  if (req.org && req.org.org_id) return req.org.org_id;
  return null;
}

function optionalAuth(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return next();
  authenticateToken(req, res, (err) => next()); // ignore auth errors, just proceed without req.user
}

router.get('/', optionalAuth, async (req, res) => {
  try {
    const org_id = resolveOrgId(req);
    if (!org_id) {
      return res.status(404).json({ error: 'No organization found for this request' });
    }
    const events = await getEventsByOrg(org_id);
    res.json({ events });
  } catch (error) {
    console.error('[EVENTS] List error:', error);
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

router.post('/', authenticateToken, async (req, res) => {
  try {
    const org_id = req.user.org_id;
    if (!req.body.title || !req.body.date) {
      return res.status(400).json({ error: 'title and date are required' });
    }
    const event = await createEvent(org_id, req.body);
    res.json({ success: true, event, duplicate: !!event.duplicate });
  } catch (error) {
    console.error('[EVENTS] Create error:', error);
    res.status(500).json({ error: 'Failed to create event' });
  }
    // Query using GSI org-index to get events for this org
    });

router.put('/:event_id', authenticateToken, async (req, res) => {
  try {
    const updated = await updateEvent(req.params.event_id, req.user.org_id, req.body);
    if (!updated) return res.status(404).json({ error: 'Event not found' });
    res.json({ success: true, event: updated });

  } catch (error) {
    console.error('[EVENTS] Update error:', error);
    // Return empty — chatbot still works with FAISS knowledge base only
    res.status(500).json({ error: 'Failed to update event' });
  }
});

// ── POST /api/events/sync ────────────────────────────────────────────────────
// Bulk push all events from frontend localStorage → DynamoDB
// Run once from browser console after deploy
router.delete('/:event_id', authenticateToken, async (req, res) => {




    try {
    const ok = await deleteEvent(req.params.event_id, req.user.org_id);
    if (!ok) return res.status(404).json({ error: 'Event not found' });


// ── POST /api/events ─────────────────────────────────────────────────────────
// Add single event (admin)





// ── DELETE /api/events/:eventId ──────────────────────────────────────────────
    res.json({ success: true });
  } catch (error) {
    console.error('[EVENTS] Delete error:', error);
    res.status(500).json({ error: 'Failed to delete event' });
  }
});

// ── Admin guard ───────────────────────────────────────────────────────────────

module.exports = router;
