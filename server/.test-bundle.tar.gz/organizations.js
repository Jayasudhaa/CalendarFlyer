/**
 * Organization Management Module
 * Handles CRUD operations for organizations (tenants)
 */

const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, GetCommand, QueryCommand, UpdateCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const { v4: uuidv4 } = require('uuid');

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-2' });
const dynamodb = DynamoDBDocumentClient.from(client);

const ORGANIZATIONS_TABLE = 'calendarfly_organizations';

// Feature flags for different plans
const PLAN_FEATURES = {
  free: {
    calendar: true,
    flyer_editor: false,
    broadcast: false,
    rsvp: false,
    chatbot: false,
    temple_library: false,
    analytics: false,
    custom_domain: false,
    api_access: false
  },
  starter: {
    calendar: true,
    flyer_editor: true,
    broadcast: true,
    rsvp: true,
    chatbot: true,
    temple_library: true,
    analytics: false,
    custom_domain: false,
    api_access: false
  },
  pro: {
    calendar: true,
    flyer_editor: true,
    broadcast: true,
    rsvp: true,
    chatbot: true,
    temple_library: true,
    analytics: true,
    custom_domain: false,
    api_access: false
  },
  enterprise: {
    calendar: true,
    flyer_editor: true,
    broadcast: true,
    rsvp: true,
    chatbot: true,
    temple_library: true,
    analytics: true,
    custom_domain: true,
    api_access: true,
    white_label: true
  }
};

// Limit key names previously didn't match what checkLimit() assumed: it
// always read `${resource}_per_month`, which matched events/flyers but not
// `rsvp_responses` or `chatbot_messages` (no suffix) — so checkLimit()
// silently read `undefined` as the limit for those two and always treated
// the org as over it. Never noticed because nothing actually called
// checkLimit() anywhere. Fixed here by renaming those two keys to match;
// `users` intentionally keeps no suffix — team size is a headcount cap,
// not a monthly quota, and is checked separately (see checkUserLimit).
const PLAN_LIMITS = {
  free: {
    events_per_month: 10,
    flyers_per_month: 0,
    rsvp_responses_per_month: 50,
    chatbot_messages_per_month: 0,
    users: 1,
    storage_gb: 1,
    ai_images_per_month: 30
  },
  starter: {
    events_per_month: 50,
    flyers_per_month: 20,
    rsvp_responses_per_month: 500,
    chatbot_messages_per_month: 500,
    users: 3,
    storage_gb: 5,
    ai_images_per_month: 150
  },
  pro: {
    events_per_month: -1,  // unlimited
    flyers_per_month: -1,
    rsvp_responses_per_month: -1,
    chatbot_messages_per_month: 2000,
    users: 10,
    storage_gb: 20,
    ai_images_per_month: -1
  },
  enterprise: {
    events_per_month: -1,
    flyers_per_month: -1,
    rsvp_responses_per_month: -1,
    chatbot_messages_per_month: -1,
    users: -1,
    storage_gb: 100,
    ai_images_per_month: -1
  }
};

// Price charged for each AI-generated image beyond the plan's free monthly
// allowance. This is a RECORD-KEEPING figure only — Checkout/webhooks now
// exist (routes/billing.js) for the subscription itself, but per-unit
// overage still isn't charged to the card automatically; it accrues on the
// org's `billing.ai_image_overage_cents` balance for now. $0.75/image is
// roughly a 3x markup over gpt-image-1's real per-image cost (~$0.25 at
// high quality/portrait size as of Aug 2026) to cover margin — adjust
// freely, it's just a constant.
const AI_IMAGE_PRICE_CENTS = 75;

// Same idea for chatbot messages (temple-bot / admin-assistant / welcome-
// intent — see routes/chat.js), which also cost real money per call
// (Anthropic API). A short Claude Sonnet completion costs a small fraction
// of a cent; 5¢/message is a healthy margin, not a cost-reflective price —
// adjust freely.
const CHATBOT_MESSAGE_PRICE_CENTS = 5;

/**
 * Create a new organization
 */
async function createOrganization(data) {
  const org_id = `org-${uuidv4()}`;
  const plan = data.plan || 'free';
  
  const organization = {
    org_id,
    name: data.name,
    subdomain: data.subdomain,
    custom_domain: data.custom_domain || null,
    logo_url: data.logo_url || null,
    banner_url: data.banner_url || null,
    address: data.address || '',
    phone: data.phone || '',
    manager_phone: data.manager_phone || '',
    primary_color: data.primary_color || '#ea580c',
    secondary_color: data.secondary_color || '#fff7ed',
    plan: plan,
    stripe_customer_id: data.stripe_customer_id || null,
    stripe_subscription_id: data.stripe_subscription_id || null,
    trial_ends_at: data.trial_ends_at || (Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
    features: PLAN_FEATURES[plan],
    limits: PLAN_LIMITS[plan],
    usage: {
      events_this_month: 0,
      flyers_this_month: 0,
      rsvp_responses_this_month: 0,
      chatbot_messages_this_month: 0,
      ai_images_this_month: 0,
      storage_used_gb: 0
    },
    // Not reset monthly — an accruing balance of what's owed for AI images
    // generated past the free monthly allowance (ai_image_overage_cents),
    // plus this org's Stripe subscription/trial state. card_on_file flips
    // true only once a Checkout Session actually completes (see
    // routes/billing.js's webhook handler) — never set it any other way.
    billing: {
      ai_image_overage_cents: 0,
      card_on_file: false,
      subscription_status: plan === 'free' ? 'none' : 'trialing'
    },
    created_at: Date.now(),
    updated_at: Date.now()
  };

  await dynamodb.send(new PutCommand({
    TableName: ORGANIZATIONS_TABLE,
    Item: organization
  }));

  return organization;
}

/**
 * Downgrade an org to the free plan once its trial has ended with no card
 * on file — the "then upgrade" half of the 1-week-free-trial flow. Runs
 * lazily on every read rather than a scheduled job: no cron infrastructure
 * exists in this codebase, and a read-time check is simpler and can't
 * silently stop running. A no-op for orgs already on 'free', still inside
 * their trial window, or with a card already on file (billing.card_on_file
 * only flips true once Stripe Checkout actually completes — see
 * routes/billing.js — so this can't downgrade someone who's already paying).
 */
async function settleTrial(org) {
  if (!org) return org;

  const trialExpired = org.plan !== 'free'
    && !(org.billing && org.billing.card_on_file)
    && org.trial_ends_at
    && org.trial_ends_at <= Date.now();

  if (trialExpired) {
    console.log(`[TRIAL] Trial ended with no card for org ${org.org_id} — downgrading to free`);
    org = await updateOrganization(org.org_id, {
      plan: 'free',
      features: PLAN_FEATURES.free,
      limits: PLAN_LIMITS.free,
      billing: { ...(org.billing || {}), subscription_status: 'trial_expired' },
    });
  }

  return applyFeatureOverrides(org);
}

/**
 * Platform-admin per-org feature overrides (see PUT /api/admin/organizations/
 * :org_id/features) — lets the site owner flip a specific feature on or off
 * for one org regardless of its plan (comp a feature for a customer, kill
 * switch a feature that's misbehaving for one tenant, etc.) without having
 * to change their plan. Stored separately from `features` so a plan change
 * doesn't silently wipe a support-granted override; merged in at every read
 * so callers never have to know overrides exist — they just read
 * `org.features` like always and get the effective value.
 */
function applyFeatureOverrides(org) {
  if (!org) return org;
  if (!org.feature_overrides || Object.keys(org.feature_overrides).length === 0) return org;
  return {
    ...org,
    features: { ...(PLAN_FEATURES[org.plan] || org.features || {}), ...org.feature_overrides },
  };
}

/**
 * Get organization by ID
 */
async function getOrganization(org_id) {
  const result = await dynamodb.send(new GetCommand({
    TableName: ORGANIZATIONS_TABLE,
    Key: { org_id }
  }));

  return settleTrial(result.Item);
}

/**
 * Get organization by subdomain
 */
async function getOrganizationBySubdomain(subdomain) {
  const result = await dynamodb.send(new QueryCommand({
    TableName: ORGANIZATIONS_TABLE,
    IndexName: 'subdomain-index',
    KeyConditionExpression: 'subdomain = :subdomain',
    ExpressionAttributeValues: {
      ':subdomain': subdomain
    }
  }));

  return settleTrial(result.Items && result.Items.length > 0 ? result.Items[0] : null);
}

/**
 * Get organization by custom domain
 */
/**
 * Get organization by custom domain
 * Note: This scans the table since we don't have an index on custom_domain
 * For production with many orgs, we'd add the index with sparse handling
 */
async function getOrganizationByDomain(domain) {
  const result = await dynamodb.send(new ScanCommand({
    TableName: ORGANIZATIONS_TABLE,
    FilterExpression: 'custom_domain = :domain',
    ExpressionAttributeValues: {
      ':domain': domain
    }
  }));

  return settleTrial(result.Items && result.Items.length > 0 ? result.Items[0] : null);
}

/**
 * Get organization by Stripe customer ID — used by the billing webhook,
 * which only has Stripe object IDs to go on, not our own org_id. Same
 * scan-based tradeoff as getOrganizationByDomain above (no index on this
 * field); fine at this app's scale, worth an index if that changes.
 */
async function getOrganizationByStripeCustomerId(customerId) {
  const result = await dynamodb.send(new ScanCommand({
    TableName: ORGANIZATIONS_TABLE,
    FilterExpression: 'stripe_customer_id = :cid',
    ExpressionAttributeValues: {
      ':cid': customerId
    }
  }));

  return settleTrial(result.Items && result.Items.length > 0 ? result.Items[0] : null);
}

/**
 * Update organization
 */
async function updateOrganization(org_id, updates) {
  const updateExpressions = [];
  const expressionAttributeNames = {};
  const expressionAttributeValues = {};

  Object.keys(updates).forEach((key, index) => {
    const placeholder = `:val${index}`;
    const namePlaceholder = `#${key}`;
    updateExpressions.push(`${namePlaceholder} = ${placeholder}`);
    expressionAttributeNames[namePlaceholder] = key;
    expressionAttributeValues[placeholder] = updates[key];
  });

  expressionAttributeNames['#updated_at'] = 'updated_at';
  expressionAttributeValues[':updated_at'] = Date.now();
  updateExpressions.push('#updated_at = :updated_at');

  await dynamodb.send(new UpdateCommand({
    TableName: ORGANIZATIONS_TABLE,
    Key: { org_id },
    UpdateExpression: `SET ${updateExpressions.join(', ')}`,
    ExpressionAttributeNames: expressionAttributeNames,
    ExpressionAttributeValues: expressionAttributeValues
  }));

  return getOrganization(org_id);
}

/**
 * Change organization plan
 */
async function changePlan(org_id, newPlan) {
  return updateOrganization(org_id, {
    plan: newPlan,
    features: PLAN_FEATURES[newPlan],
    limits: PLAN_LIMITS[newPlan]
  });
}

/**
 * Check if organization can use feature
 */
function canUseFeature(organization, feature) {
  return organization.features[feature] === true;
}

/**
 * Check if organization is within usage limits for a monthly-resetting
 * resource ('events', 'flyers', 'rsvp_responses', or 'chatbot_messages').
 * Team size ('users') doesn't reset monthly and isn't tracked in `usage` at
 * all — use checkUserLimit() for that instead.
 */
function checkLimit(organization, resource) {
  const limit = organization.limits[`${resource}_per_month`];
  const usage = organization.usage[`${resource}_this_month`] || 0;

  if (limit == null || limit === -1) return true; // unlimited, or not tracked
  return usage < limit;
}

/**
 * How many users currently belong to an org (via the org-index GSI on
 * calendarfly_users) — a live headcount, not an incrementing counter.
 * Shared by checkUserLimit() and the /me endpoint's team-usage display.
 */
async function countOrgUsers(org_id) {
  const result = await dynamodb.send(new QueryCommand({
    TableName: 'calendarfly_users',
    IndexName: 'org-index',
    KeyConditionExpression: 'org_id = :org_id',
    ExpressionAttributeValues: { ':org_id': org_id },
    Select: 'COUNT',
  }));
  return result.Count || 0;
}

/**
 * Team size is a headcount cap, not a monthly counter — checking it means
 * counting how many users currently belong to the org, not reading an
 * incrementing field. Returns true if the org can add one more user right
 * now.
 */
async function checkUserLimit(org_id, organization) {
  const limit = organization.limits && organization.limits.users;
  if (limit == null || limit === -1) return true; // unlimited
  const count = await countOrgUsers(org_id);
  return count < limit;
}

/**
 * Increment usage counter
 */
async function incrementUsage(org_id, resource) {
  await dynamodb.send(new UpdateCommand({
    TableName: ORGANIZATIONS_TABLE,
    Key: { org_id },
    UpdateExpression: 'ADD #usage.#resource :inc',
    ExpressionAttributeNames: {
      '#usage': 'usage',
      '#resource': `${resource}_this_month`
    },
    ExpressionAttributeValues: {
      ':inc': 1
    }
  }));
}

/**
 * Record one AI-generated image against an org's monthly free allowance,
 * accruing an overage charge on `billing.ai_image_overage_cents` once that
 * allowance is used up. Deliberately never blocks generation — the request
 * that got us here already succeeded; this just tracks what's owed.
 *
 * Read-modify-write rather than a blind DynamoDB ADD: `billing` doesn't
 * exist on orgs created before this field was added, and ADD can't create
 * an attribute inside a map that isn't there yet. This trades perfect
 * atomicity under simultaneous requests from the same org (unrealistic for
 * a single temple's flyer generation) for code that works for every org
 * regardless of when it was created.
 */
async function recordAiImageUsage(org_id) {
  const org = await getOrganization(org_id);
  if (!org) return null;

  const limit = (org.limits && org.limits.ai_images_per_month) ?? PLAN_LIMITS[org.plan]?.ai_images_per_month ?? 30;
  const usedBefore = (org.usage && org.usage.ai_images_this_month) || 0;
  const usedAfter = usedBefore + 1;
  const isUnlimited = limit === -1;
  const overLimit = !isUnlimited && usedAfter > limit;

  const overageBefore = (org.billing && org.billing.ai_image_overage_cents) || 0;
  const overageAfter = overLimit ? overageBefore + AI_IMAGE_PRICE_CENTS : overageBefore;

  // `billing` is a newer field — orgs created before it existed won't have
  // the map at all yet, and DynamoDB can't SET a nested attribute whose
  // parent map is missing. Overwrite the whole `billing` object (computed
  // above from a full read) instead of a nested path, so this works
  // whether or not the org already had one.
  await dynamodb.send(new UpdateCommand({
    TableName: ORGANIZATIONS_TABLE,
    Key: { org_id },
    UpdateExpression: 'SET #usage.#aiImages = :usedAfter, #billing = :billingObj, #updated_at = :now',
    ExpressionAttributeNames: {
      '#usage': 'usage',
      '#aiImages': 'ai_images_this_month',
      '#billing': 'billing',
      '#updated_at': 'updated_at',
    },
    ExpressionAttributeValues: {
      ':usedAfter': usedAfter,
      ':billingObj': { ...(org.billing || {}), ai_image_overage_cents: overageAfter },
      ':now': Date.now(),
    },
  }));

  return {
    used: usedAfter,
    limit,
    isUnlimited,
    overLimit,
    overageCentsAdded: overLimit ? AI_IMAGE_PRICE_CENTS : 0,
    totalOverageCents: overageAfter,
  };
}

/**
 * Same shape as recordAiImageUsage, for chatbot messages instead. Unlike
 * AI images, the Free plan blocks chatbot entirely (limit is 0) — routes/
 * chat.js checks that BEFORE calling Claude and never reaches this
 * function for a blocked request, so this only ever runs for a message
 * that already succeeded, same "just track what's owed" role.
 */
async function recordChatbotMessageUsage(org_id) {
  const org = await getOrganization(org_id);
  if (!org) return null;

  const limit = (org.limits && org.limits.chatbot_messages_per_month) ?? PLAN_LIMITS[org.plan]?.chatbot_messages_per_month ?? 0;
  const usedBefore = (org.usage && org.usage.chatbot_messages_this_month) || 0;
  const usedAfter = usedBefore + 1;
  const isUnlimited = limit === -1;
  const overLimit = !isUnlimited && usedAfter > limit;

  const overageBefore = (org.billing && org.billing.chatbot_message_overage_cents) || 0;
  const overageAfter = overLimit ? overageBefore + CHATBOT_MESSAGE_PRICE_CENTS : overageBefore;

  await dynamodb.send(new UpdateCommand({
    TableName: ORGANIZATIONS_TABLE,
    Key: { org_id },
    UpdateExpression: 'SET #usage.#chatbotMsgs = :usedAfter, #billing = :billingObj, #updated_at = :now',
    ExpressionAttributeNames: {
      '#usage': 'usage',
      '#chatbotMsgs': 'chatbot_messages_this_month',
      '#billing': 'billing',
      '#updated_at': 'updated_at',
    },
    ExpressionAttributeValues: {
      ':usedAfter': usedAfter,
      ':billingObj': { ...(org.billing || {}), chatbot_message_overage_cents: overageAfter },
      ':now': Date.now(),
    },
  }));

  return {
    used: usedAfter,
    limit,
    isUnlimited,
    overLimit,
    overageCentsAdded: overLimit ? CHATBOT_MESSAGE_PRICE_CENTS : 0,
    totalOverageCents: overageAfter,
  };
}

/**
 * Reset monthly usage (run this on 1st of each month)
 */
async function resetMonthlyUsage(org_id) {
  await dynamodb.send(new UpdateCommand({
    TableName: ORGANIZATIONS_TABLE,
    Key: { org_id },
    UpdateExpression: 'SET #usage = :reset',
    ExpressionAttributeNames: {
      '#usage': 'usage'
    },
    ExpressionAttributeValues: {
      ':reset': {
        events_this_month: 0,
        flyers_this_month: 0,
        rsvp_responses_this_month: 0,
        chatbot_messages_this_month: 0,
        ai_images_this_month: 0,
        storage_used_gb: 0
      }
    }
  }));
}

/**
 * Redacted, client-safe view of an org's per-platform Facebook/Instagram
 * connection (see routes/organizations.js PUT /settings, which is where
 * social_accounts gets written) — whether a connection is on file plus the
 * non-secret Page ID / Instagram Account ID, and NEVER the Facebook Page
 * access token itself. Shared by every response that hands `organization`
 * to the client (login, Google login, GET /me, PUT /settings) so none of
 * them can accidentally leak the token into browser localStorage.
 */
function redactSocialAccounts(org) {
  const social = (org && org.social_accounts) || {};
  return {
    facebook: {
      connected: !!(social.facebook && social.facebook.page_token),
      page_id: (social.facebook && social.facebook.page_id) || '',
      page_name: (social.facebook && social.facebook.page_name) || '',
      connected_via: (social.facebook && social.facebook.connected_via) || ''
    },
    instagram: {
      connected: !!(social.instagram && social.instagram.account_id),
      account_id: (social.instagram && social.instagram.account_id) || '',
      username: (social.instagram && social.instagram.username) || '',
      connected_via: (social.instagram && social.instagram.connected_via) || ''
    },
    // Added alongside the WhatsApp Embedded Signup flow (routes/
    // social-connect.js) — never echoes the token, same as the other two.
    whatsapp: {
      connected: !!(social.whatsapp && social.whatsapp.token && social.whatsapp.phone_id),
      phone_id: (social.whatsapp && social.whatsapp.phone_id) || '',
      waba_id: (social.whatsapp && social.whatsapp.waba_id) || '',
      connected_via: (social.whatsapp && social.whatsapp.connected_via) || ''
    }
  };
}

/**
 * List all organizations (admin only)
 */
async function listOrganizations() {
  const result = await dynamodb.send(new ScanCommand({
    TableName: ORGANIZATIONS_TABLE
  }));

  return result.Items;
}

module.exports = {
  createOrganization,
  getOrganization,
  getOrganizationBySubdomain,
  getOrganizationByDomain,
  getOrganizationByStripeCustomerId,
  updateOrganization,
  settleTrial,
  changePlan,
  canUseFeature,
  checkLimit,
  checkUserLimit,
  countOrgUsers,
  incrementUsage,
  recordAiImageUsage,
  recordChatbotMessageUsage,
  resetMonthlyUsage,
  listOrganizations,
  redactSocialAccounts,
  PLAN_FEATURES,
  PLAN_LIMITS,
  AI_IMAGE_PRICE_CENTS,
  CHATBOT_MESSAGE_PRICE_CENTS
};
